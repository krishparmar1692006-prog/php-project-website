<?php
/**
 * PRODUCT DETAIL PAGE
 * Loads one product by ID from the database (dynamic).
 */
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    setFlash('warning', 'Invalid product.');
    redirect('products.php');
}
require_once __DIR__ . '/includes/header.php';

$product = fetchProduct($pdo, $id);
if (!$product || $product['status'] != 1) {
    setFlash('error', 'This product is not available.');
    redirect('products.php');
}
$price = sellingPrice($product);
$pct   = discountPercent($product['price'], $product['discount_price']);

/* Related products (same category) */
$rel = $pdo->prepare('SELECT * FROM products WHERE status=1 AND category_id=? AND id<>? ORDER BY rating DESC LIMIT 4');
$rel->execute([$product['category_id'], $product['id']]);
$related = $rel->fetchAll();
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item"><a href="categories.php">Categories</a></li>
    <li class="breadcrumb-item"><a href="products.php?category=<?php echo (int)$product['category_id']; ?>"><?php echo e($product['category_name']); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e($product['name']); ?></li>
  </ol></nav>

  <div class="row g-4">
    <!-- Product image -->
    <div class="col-md-5">
      <div class="card border-0 shadow-sm">
        <div class="card-body p-4 text-center">
          <img src="<?php echo img_url($product['image']); ?>" alt="<?php echo e($product['name']); ?>" class="img-fluid" style="max-height:380px;object-fit:contain;">
        </div>
      </div>
    </div>
    <!-- Product info -->
    <div class="col-md-7">
      <h2 class="fw-bold"><?php echo e($product['name']); ?></h2>
      <div class="mb-2">
        <span class="badge bg-warning text-dark"><i class="bi bi-star-fill"></i> <?php echo e($product['rating']); ?></span>
        <span class="badge bg-light text-muted ms-1"><?php echo e($product['category_name']); ?></span>
      </div>
      <div class="product-price mb-3">
        <span class="price fs-3 fw-bold text-primary"><?php echo money($price); ?></span>
        <?php if ($pct > 0): ?>
          <span class="old-price fs-5 ms-2"><?php echo money($product['price']); ?></span>
          <span class="discount-badge position-static ms-2 d-inline-block">Save <?php echo $pct; ?>%</span>
        <?php endif; ?>
      </div>
      <p class="text-muted"><?php echo nl2br(e($product['description'])); ?></p>

      <?php if (!empty($product['specifications'])): ?>
        <div class="card bg-light border-0 mb-3">
          <div class="card-body py-2">
            <h6 class="fw-bold mb-2">Key Specifications</h6>
            <ul class="small mb-0">
              <?php foreach (explode('|', $product['specifications']) as $spec): ?>
                <li><?php echo e(trim($spec)); ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>
      <?php endif; ?>

      <div class="mb-3">
        <?php if ($product['stock'] > 0): ?>
          <span class="badge text-bg-success"><i class="bi bi-check-circle me-1"></i>In Stock &mdash; <?php echo (int)$product['stock']; ?> units</span>
        <?php else: ?>
          <span class="badge text-bg-danger">Out of Stock</span>
        <?php endif; ?>
        <?php if (!empty($product['created_at'])): ?>
          <span class="text-muted small ms-2">Listed: <?php echo date('d M Y', strtotime($product['created_at'])); ?></span>
        <?php endif; ?>
      </div>

      <form method="get" action="cart.php" class="d-flex align-items-center gap-2 mb-3">
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="id" value="<?php echo (int)$product['id']; ?>">
        <label class="form-label mb-0 me-1">Qty</label>
        <select name="qty" class="form-select w-auto" <?php echo $product['stock'] > 0 ? '' : 'disabled'; ?>>
          <?php for ($i = 1; $i <= min(10, max(1, $product['stock'])); $i++): ?>
            <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
          <?php endfor; ?>
        </select>
        <button type="submit" class="btn btn-brand" <?php echo $product['stock'] > 0 ? '' : 'disabled'; ?>><i class="bi bi-cart-plus me-1"></i>Add to Cart</button>
        <button type="submit" name="buynow" value="1" class="btn btn-warning" <?php echo $product['stock'] > 0 ? '' : 'disabled'; ?>><i class="bi bi-lightning-charge me-1"></i>Buy Now</button>
      </form>
    </div>
  </div>

  <?php if ($related): ?>
  <h4 class="section-title mt-5 mb-3">Related Products</h4>
  <div class="row g-3">
    <?php foreach ($related as $rp):
        $rprice = sellingPrice($rp); ?>
      <div class="col-6 col-md-3">
        <div class="product-card">
          <div class="thumb"><img src="<?php echo img_url($rp['image']); ?>" alt="<?php echo e($rp['name']); ?>"></div>
          <div class="card-body p-3">
            <h6 class="card-title text-truncate mb-1"><a href="product.php?id=<?php echo (int)$rp['id']; ?>" class="text-decoration-none text-dark"><?php echo e($rp['name']); ?></a></h6>
            <div class="product-price mb-2"><span class="price"><?php echo money($rprice); ?></span></div>
            <a href="product.php?id=<?php echo (int)$rp['id']; ?>" class="btn btn-brand-outline btn-sm w-100">View</a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
