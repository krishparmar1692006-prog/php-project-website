<?php
/** REGISTER PAGE - new user sign-up with validation + password hashing. */
$pageTitle = 'Register';
require_once __DIR__ . '/includes/header.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$errors = [];
$old = ['name'=>'','email'=>'','mobile'=>'','address'=>'','city'=>'','state'=>'','pincode'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($old as $k => $v) {
        $old[$k] = trim($_POST[$k] ?? '');
    }
    $password        = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($old['name'] === '') $errors['name'] = 'Full name is required.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Valid email required.';
    $chk = $pdo->prepare('SELECT id FROM users WHERE email = ?');
    $chk->execute([$old['email']]);
    if ($chk->fetch()) $errors['email'] = 'This email is already registered. Login instead.';
    if (!preg_match('/^[0-9+\- ]{10,15}$/', $old['mobile'])) $errors['mobile'] = 'Valid mobile number required.';
    if (strlen($password) < 6) $errors['password'] = 'Password must be at least 6 characters.';
    if ($password !== $confirmPassword) $errors['confirm_password'] = 'Passwords do not match.';
    if (!empty($old['pincode']) && !preg_match('/^\d{6}$/', $old['pincode'])) $errors['pincode'] = 'Pincode must be 6 digits.';

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO users (name, email, mobile, password, address, city, state, pincode, status) VALUES (?,?,?,?,?,?,?,?,1)');
        $stmt->execute([$old['name'], $old['email'], $old['mobile'], $hash, $old['address'], $old['city'], $old['state'], $old['pincode']]);
        setFlash('success', 'Account created! Please log in.');
        redirect('login.php');
    }
}
?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
      <div class="card border-0 shadow-sm">
        <div class="card-body p-4 p-md-5">
          <div class="text-center mb-4">
            <i class="bi bi-person-plus display-4 text-primary"></i>
            <h4 class="fw-bold mt-2">Create Account</h4>
            <p class="text-muted small">Join TechCart to shop fast &amp; track every order</p>
          </div>
          <?php if ($errors): ?>
            <div class="alert alert-danger">
              <ul class="mb-0"><?php foreach ($errors as $er) echo '<li>' . e($er) . '</li>'; ?></ul>
            </div>
          <?php endif; ?>
          <form method="post" action="register.php">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label required">Full Name</label>
                <input type="text" name="name" class="form-control <?php echo isset($errors['name']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['name']); ?>">
                <div class="invalid-feedback"><?php echo e($errors['name'] ?? ''); ?></div>
              </div>
              <div class="col-md-6">
                <label class="form-label required">Email</label>
                <input type="email" name="email" class="form-control <?php echo isset($errors['email']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['email']); ?>">
                <div class="invalid-feedback"><?php echo e($errors['email'] ?? ''); ?></div>
              </div>
              <div class="col-md-6">
                <label class="form-label required">Mobile Number</label>
                <input type="text" name="mobile" class="form-control <?php echo isset($errors['mobile']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['mobile']); ?>">
                <div class="invalid-feedback"><?php echo e($errors['mobile'] ?? ''); ?></div>
              </div>
              <div class="col-md-6">
                <label class="form-label required">Password</label>
                <input type="password" name="password" class="form-control <?php echo isset($errors['password']) ? 'is-invalid' : ''; ?>">
                <div class="invalid-feedback"><?php echo e($errors['password'] ?? ''); ?></div>
              </div>
              <div class="col-md-6">
                <label class="form-label required">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control <?php echo isset($errors['confirm_password']) ? 'is-invalid' : ''; ?>">
                <div class="invalid-feedback"><?php echo e($errors['confirm_password'] ?? ''); ?></div>
              </div>
              <div class="col-md-6">
                <label class="form-label">Address</label>
                <input type="text" name="address" class="form-control" value="<?php echo e($old['address']); ?>">
              </div>
              <div class="col-md-4">
                <label class="form-label">City</label>
                <input type="text" name="city" class="form-control" value="<?php echo e($old['city']); ?>">
              </div>
              <div class="col-md-4">
                <label class="form-label">State</label>
                <input type="text" name="state" class="form-control" value="<?php echo e($old['state']); ?>">
              </div>
              <div class="col-md-4">
                <label class="form-label">Pincode</label>
                <input type="text" name="pincode" class="form-control <?php echo isset($errors['pincode']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['pincode']); ?>">
                <div class="invalid-feedback"><?php echo e($errors['pincode'] ?? ''); ?></div>
              </div>
            </div>
            <button type="submit" class="btn btn-brand w-100 mt-4"><i class="bi bi-person-plus-fill me-1"></i>Register</button>
          </form>
          <hr>
          <p class="text-center small mb-0">Already have an account? <a href="login.php">Login</a></p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
