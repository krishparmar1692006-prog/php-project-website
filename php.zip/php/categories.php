<?php
/** CATEGORY PAGE - lists all product categories dynamically */
$pageTitle = 'Categories';
require_once __DIR__ . '/includes/header.php';
$categories = fetchCategories($pdo, true);
$total      = $pdo->query('SELECT COUNT(*) c FROM products WHERE status=1')->fetch()['c'];
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item active">Categories</li>
  </ol></nav>
  <h3 class="section-title mb-1">All Categories</h3>
  <p class="text-muted"><?php echo count($categories); ?> categories &middot; <?php echo (int)$total; ?> products available</p>

  <div class="row g-3 mt-2">
    <?php if (!$categories): ?>
      <div class="col-12"><div class="alert alert-info">No categories available right now.</div></div>
    <?php endif; ?>
    <?php foreach ($categories as $cat):
        $count = (int)$pdo->query('SELECT COUNT(*) c FROM products WHERE status=1 AND category_id=' . (int)$cat['id'])->fetch()['c']; ?>
      <div class="col-6 col-md-4 col-lg-3">
        <div class="category-card text-start">
          <img src="<?php echo img_url($cat['image']); ?>" alt="<?php echo e($cat['name']); ?>">
          <h5 class="fw-bold mb-1"><?php echo e($cat['name']); ?></h5>
          <p class="text-muted small mb-2" style="min-height:2.5rem;"><?php echo e($cat['description']); ?></p>
          <span class="btn btn-brand btn-sm"><i class="bi bi-bag me-1"></i><?php echo $count; ?> Products</span>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
