<?php
/** LOGOUT - destroys the customer session. */
require_once __DIR__ . '/includes/config.php';
session_unset();
session_destroy();
redirect('index.php');
