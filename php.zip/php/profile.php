<?php
/**
 * MY PROFILE PAGE - logged-in users can view & update their profile.
 */
$pageTitle = 'My Profile';
require_once __DIR__ . '/includes/header.php';

if (!isLoggedIn()) {
    setFlash('warning', 'Please log in first.');
    redirect('login.php');
}

$user = currentUser($pdo);
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $mobile  = trim($_POST['mobile'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city    = trim($_POST['city'] ?? '');
    $state   = trim($_POST['state'] ?? '');
    $pincode = trim($_POST['pincode'] ?? '');
    $newPass = $_POST['new_password'] ?? '';

    if ($name === '') $errors[] = 'Name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email required.';

    // email uniqueness (excluding self)
    $chk = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id <> ?');
    $chk->execute([$email, $user['id']]);
    if ($chk->fetch()) $errors[] = 'This email is already registered.';
    if (!preg_match('/^[0-9+\- ]{10,15}$/', $mobile)) $errors[] = 'Valid mobile number required.';
    if (!empty($pincode) && !preg_match('/^\d{6}$/', $pincode)) $errors[] = 'Pincode must be 6 digits.';
    if (!empty($newPass) && strlen($newPass) < 6) $errors[] = 'Password must be at least 6 characters.';

    if (!$errors) {
        if (!empty($newPass)) {
            $hash = password_hash($newPass, PASSWORD_DEFAULT);
            $upd = $pdo->prepare('UPDATE users SET name=?, email=?, mobile=?, address=?, city=?, state=?, pincode=?, password=? WHERE id=?');
            $upd->execute([$name, $email, $mobile, $address, $city, $state, $pincode, $hash, $user['id']]);
        } else {
            $upd = $pdo->prepare('UPDATE users SET name=?, email=?, mobile=?, address=?, city=?, state=?, pincode=? WHERE id=?');
            $upd->execute([$name, $email, $mobile, $address, $city, $state, $pincode, $user['id']]);
        }
        setFlash('success', 'Profile updated successfully.');
        redirect('profile.php');
    }
}
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item active">My Profile</li>
  </ol></nav>
  <h3 class="section-title mb-4">My Profile</h3>

  <?php if ($errors): ?>
    <div class="alert alert-danger"><?php echo implode('<br>', array_map('e', $errors)); ?></div>
  <?php endif; ?>

  <div class="row g-4">
    <div class="col-md-4">
      <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-4">
          <i class="bi bi-person-circle display-1 text-primary"></i>
          <h5 class="fw-bold mt-3 mb-0"><?php echo e($user['name']); ?></h5>
          <p class="text-muted mb-2"><?php echo e($user['email']); ?></p>
          <span class="badge bg-success">Active Account</span>
          <hr>
          <div class="text-start small">
            <div class="d-flex justify-content-between mb-1"><span>Member since</span><span><?php echo date('d M Y', strtotime($user['created_at'])); ?></span></div>
            <div class="d-flex justify-content-between"><span>Orders placed</span>
              <span><?php echo (int)$pdo->query('SELECT COUNT(*) c FROM orders WHERE user_id=' . (int)$user['id'])->fetch()['c']; ?></span>
            </div>
          </div>
          <a href="orders.php" class="btn btn-brand-outline btn-sm w-100 mt-3"><i class="bi bi-box-seam me-1"></i>View Order History</a>
        </div>
      </div>
    </div>
    <div class="col-md-8">
      <form method="post" action="profile.php" class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="fw-bold mb-3">Edit Information</h5>
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label required">Full Name</label>
              <input type="text" name="name" class="form-control" value="<?php echo e($user['name']); ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label required">Email</label>
              <input type="email" name="email" class="form-control" value="<?php echo e($user['email']); ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label required">Mobile Number</label>
              <input type="text" name="mobile" class="form-control" value="<?php echo e($user['mobile']); ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">New Password <span class="text-muted small">(leave blank to keep)</span></label>
              <input type="password" name="new_password" class="form-control" placeholder="••••••••">
            </div>
            <div class="col-12">
              <label class="form-label">Address</label>
              <input type="text" name="address" class="form-control" value="<?php echo e($user['address']); ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">City</label>
              <input type="text" name="city" class="form-control" value="<?php echo e($user['city']); ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">State</label>
              <input type="text" name="state" class="form-control" value="<?php echo e($user['state']); ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">Pincode</label>
              <input type="text" name="pincode" class="form-control" value="<?php echo e($user['pincode']); ?>">
            </div>
          </div>
          <button type="submit" class="btn btn-brand mt-4"><i class="bi bi-check2-circle me-1"></i>Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
