/* TechCart - small front-end helpers */
document.addEventListener('DOMContentLoaded', function () {
  // confirm on delete forms
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      if (!window.confirm(form.getAttribute('data-confirm'))) {
        ev.preventDefault();
      }
    });
  });
  // auto-dismiss alerts after 4s
  window.setTimeout(function () {
    document.querySelectorAll('.alert-dismissible').forEach(function (a) { a.remove(); });
  }, 4000);
});
