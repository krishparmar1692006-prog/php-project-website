#!/usr/bin/env python3
"""Generate flat-design SVG assets for TechCart:
banners, category icons, product illustrations, favicon/placeholder."""
import os

OUT = "/home/user/techcart/assets/images"
os.makedirs(OUT, exist_ok=True)

# ---------- generic helpers ----------
def bg_svg(w, h, gradient):
    return (f'<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
            f'<stop offset="0" stop-color="{gradient[0]}"/><stop offset="1" stop-color="{gradient[1]}"/>'
            f'</linearGradient></defs>'
            f'<rect width="{w}" height="{h}" fill="url(#g)"/>')

def open_svg(w=600, h=600):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}">'

def close_svg():
    return '</svg>'

def circle(cx, cy, r, fill, opacity=1):
    return f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}" fill-opacity="{opacity}"/>'

def rect(x, y, w, h, rx, fill, rotate=None, opacity=1):
    t = f' transform="rotate({rotate})"' if rotate else ''
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" fill-opacity="{opacity}"{t}/>'

def poly(points, fill, opacity=1, stroke=None):
    s = f' stroke="{stroke}"' if stroke else ''
    return f'<polygon points="{points}" fill="{fill}" fill-opacity="{opacity}"{s}/>'

def text(x, y, size, fill, content, anchor="middle", weight=700):
    return (f'<text x="{x}" y="{y}" font-family="Arial, sans-serif" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{content}</text>')

DARK = "#0f172a"
BLUE = "#2563eb"
LBLUE = "#93c5fd"
BG1 = "#eef4ff"
BG2 = "#c7dbff"

# ---------- shared product scene builders ----------
def add_floor():
    return (f'<ellipse cx="300" cy="510" rx="230" ry="34" fill="#0f172a" fill-opacity="0.08"/>'
            f'<ellipse cx="300" cy="508" rx="160" ry="20" fill="#0f172a" fill-opacity="0.10"/>')

def add_panel():
    # soft backdrop panel
    return rect(150, 80, 300, 320, 42, "rgba(255,255,255,0.75)")

def product_card(title, glyph, tint="#2563eb"):
    """Standard product illustration: floor + glyph on colored blob."""
    t2 = "#93c5fd" if tint == BLUE else tint
    return "".join([
        bg_svg(600, 600, ("#ffffff", "#ffffff")),
        f'<circle cx="300" cy="300" r="170" fill="{tint}" fill-opacity="0.12"/>',
        f'<circle cx="300" cy="300" r="120" fill="{tint}" fill-opacity="0.15"/>',
        add_floor(),
        glyph,
        text(300, 560, 30, DARK, title),
    ])

def phone_glyph():
    return "".join([
        rect(245, 150, 110, 240, 26, DARK),
        rect(253, 175, 94, 190, 18, "#ffffff"),
        rect(280, 355, 40, 8, 4, "#cbd5e1"),
        circle(300, 168, 5, "#38bdf8"),
    ])

def laptop_glyph():
    return "".join([
        rect(180, 180, 240, 150, 12, DARK),
        rect(192, 192, 216, 126, 8, "#3b82f6"),
        rect(192, 192, 216, 126, 8, LBLUE, opacity=0.9),
        rect(200, 200, 200, 110, 6, "#0f172a"),
        poly("180,330 420,330 470,372 130,372", "#334155"),
        rect(130, 366, 340, 10, 4, "#475569"),
    ])

def case_glyph():
    return "".join([
        rect(200, 185, 200, 260, 26, DARK),
        rect(214, 199, 172, 232, 18, "#3b82f6"),
        circle(300, 300, 44, "#dbeafe"),
        circle(300, 300, 30, LBLUE),
        text(300, 310, 30, BLUE, "TC"),
    ])

def powerbank_glyph():
    return "".join([
        rect(245, 170, 110, 250, 22, DARK),
        rect(255, 185, 90, 220, 14, "#1e293b"),
        rect(275, 200, 50, 70, 8, "#0ea5e9"),
        rect(282, 210, 36, 40, 6, LBLUE),
        circle(300, 300, 5, "#22c55e"),
        circle(300, 326, 5, "#eab308"),
        circle(300, 352, 5, "#f87171"),
        rect(280, 380, 40, 10, 5, "#334155"),
    ])

def headphones_glyph():
    return "".join([
        rect(240, 210, 120, 170, 30, DARK),
        circle(300, 225, 58, "#eef2ff"),
        circle(300, 225, 44, BLUE),
        rect(252, 380, 22, 60, 10, DARK),
        rect(326, 380, 22, 60, 10, DARK),
        rect(245, 230, 110, 20, 10, "#38bdf8"),
    ])

def watch_glyph():
    return "".join([
        rect(255, 170, 90, 300, 30, DARK),
        rect(262, 185, 76, 270, 18, "#0f172a"),
        rect(272, 196, 56, 248, 12, "#1e293b"),
        circle(300, 300, 20, LBLUE),
        poly("296,286 312,294 296,312", "#0f172a"),
        rect(282, 235, 36, 3, 1, "#475569"),
        rect(282, 245, 30, 3, 1, "#475569"),
        rect(282, 255, 34, 3, 1, "#475569"),
    ])

def airfryer_glyph():
    return "".join([
        rect(225, 165, 150, 150, 20, "#facc15"),
        rect(225, 165, 150, 60, 20, "#fde047"),
        rect(240, 195, 42, 12, 6, "#334155"),
        circle(300, 380, 85, "#fef3c7"),
        circle(300, 380, 65, "#ffedd5"),
        poly("300,325 320,400 280,400", "#fb923c"),
        poly("300,330 344,398 256,398", "#fdba74"),
        rect(240, 458, 120, 22, 10, DARK),
        rect(255, 468, 90, 6, 3, "#475569"),
    ])

def tablet_glyph():
    return "".join([
        rect(210, 160, 180, 290, 20, DARK),
        rect(220, 172, 160, 266, 12, "#ffffff"),
        rect(220, 172, 160, 266, 12, LBLUE, opacity=0.35),
        rect(232, 184, 136, 242, 8, "#f8fafc"),
        text(300, 240, 30, BLUE, "TC"),
        circle(300, 320, 34, "#dbeafe"),
        circle(300, 320, 22, LBLUE),
        text(300, 328, 20, BLUE, "V"),
        circle(300, 430, 5, "#cbd5e1"),
    ])

def charger_glyph():
    return "".join([
        rect(280, 130, 40, 150, 12, DARK),
        rect(292, 145, 16, 120, 6, "#f1f5f9"),
        poly("262,250 338,250 328,330 272,330", "#334155"),
        rect(270, 330, 60, 20, 6, DARK),
        rect(282, 350, 36, 90, 12, "#ffffff"),
        rect(282, 350, 36, 90, 12, LBLUE, opacity=0.5),
        rect(292, 360, 16, 60, 6, "#e2e8f0"),
        rect(294, 436, 12, 26, 6, "#94a3b8"),
    ])

def earbuds_glyph():
    return "".join([
        circle(300, 200, 62, LBLUE, 0.5),
        circle(300, 200, 46, "#ffffff"),
        rect(268, 200, 64, 8, 4, "#cbd5e1"),
        # left bud
        poly("232,190 258,208 252,224", DARK),
        circle(240, 206, 6, "#f8fafc"),
        # right bud
        poly("368,190 342,208 348,224", DARK),
        circle(360, 206, 6, "#f8fafc"),
        # case
        rect(232, 300, 136, 110, 26, DARK),
        rect(244, 312, 112, 86, 18, "#ffffff"),
        rect(244, 312, 112, 20, 10, "#e2e8f0"),
        circle(300, 380, 10, "#a5b4fc"),
    ])

def bulb_glyph():
    return "".join([
        circle(300, 250, 70, "#fbbf24"),
        circle(300, 250, 52, "#fde68a"),
        poly("280,300 320,300 312,370 288,370", "#fcd34d"),
        rect(284, 392, 32, 16, 6, "#e2e8f0"),
        poly("288,408 312,408 316,430 284,430", "#cbd5e1"),
        # light rays
        circle(300, 250, 108, "#fbbf24", 0.15),
        rect(160, 245, 14, 10, 5, "#fbbf24"),
        rect(426, 245, 14, 10, 5, "#fbbf24"),
        rect(245, 150, 10, 14, 5, "#fbbf24"),
        rect(345, 150, 10, 14, 5, "#fbbf24"),
        rect(180, 190, 12, 8, 4, "#fbbf24"),
        rect(408, 190, 12, 8, 4, "#fbbf24"),
        rect(180, 300, 12, 8, 4, "#fbbf24"),
        rect(408, 300, 12, 8, 4, "#fbbf24"),
    ])

def mouse_glyph():
    return "".join([
        rect(252, 150, 96, 230, 48, "#ffffff"),
        rect(258, 156, 84, 218, 42, LBLUE, 0.55),
        rect(260, 190, 80, 150, 40, "#dbeafe"),
        rect(294, 196, 12, 40, 6, "#0f172a"),
        rect(268, 320, 64, 8, 4, "#334155"),
        circle(300, 340, 8, "#fde047"),
        circle(270, 340, 8, "#fde047"),
    ])

def favicon_glyph():
    g = '<g>'
    g += rect(120, 60, 300, 120, 24, BLUE)
    g += rect(60, 180, 420, 100, 24, BLUE, 8)
    g += rect(150, 260, 60, 100, 10, DARK)
    g += rect(330, 260, 60, 100, 10, DARK)
    g += rect(200, 340, 140, 60, 14, DARK)
    g += circle(180, 230, 18, "#ffffff")
    g += circle(360, 230, 18, "#ffffff")
    g += circle(180, 230, 8, DARK)
    g += circle(360, 230, 8, DARK)
    g += '</g>'
    return g

# ---------- banners ----------
banners = [
    ("banner-1.svg", "Next-Gen Gadgets", "Up to 40% off smartphones, laptops & tablets", "#2563eb", "#1e40af"),
    ("banner-2.svg", "Audio & Wearables", "ANC headphones, earbuds & smart watches", "#7c3aed", "#4c1d95"),
    ("banner-3.svg", "Smart Home Sale", "Air fryers, smart bulbs & appliances", "#0ea5e9", "#0369a1"),
]

for name, title, sub, c1, c2 in banners:
    svg = open_svg(1200, 400)
    svg += bg_svg(1200, 400, (c1, c2))
    # decorative circles
    svg += circle(1050, 60, 180, "#ffffff", 0.08)
    svg += circle(120, 380, 140, "#ffffff", 0.08)
    svg += circle(680, 200, 190, "#ffffff", 0.06)
    # headline
    svg += text(90, 150, 52, "#ffffff", title, "start")
    svg += text(92, 225, 28, "#e0e7ff", sub, "start")
    # arrow chip
    svg += rect(90, 265, 210, 52, 26, "#facc15")
    svg += text(195, 300, 22, DARK, "SHOP NOW")
    # giant product icon hint
    svg += circle(940, 210, 120, "#ffffff", 0.12)
    svg += text(940, 228, 60, "#ffffff", "TC", weight=800)
    svg += close_svg()
    with open(os.path.join(OUT, name), "w") as f:
        f.write(svg)

# ---------- category icons ----------
cats = [
    ("cat-electronics.svg", "⚡", BLUE),
    ("cat-accessories.svg", "⌁", "#7c3aed"),
    ("cat-audio.svg", "♪", "#0ea5e9"),
    ("cat-home.svg", "☼", "#f59e0b"),
]
for name, sym, tint in cats:
    svg = open_svg(300, 300)
    svg += bg_svg(300, 300, ("#ffffff", "#ffffff"))
    svg += f'<circle cx="150" cy="150" r="115" fill="{tint}" fill-opacity="0.14"/>'
    svg += f'<circle cx="150" cy="150" r="82" fill="{tint}" fill-opacity="0.18"/>'
    svg += text(150, 172, 84, tint, sym, weight=800)
    svg += close_svg()
    with open(os.path.join(OUT, name), "w") as f:
        f.write(svg)

# ---------- products / favicon / placeholder ----------
products = [
    ("product-1.svg", phone_glyph(), "Aurora X20", BLUE),
    ("product-2.svg", laptop_glyph(), "Nexa Laptop", "#4f46e5"),
    ("product-3.svg", case_glyph(), "ArmorPro Cover", "#0ea5e9"),
    ("product-4.svg", powerbank_glyph(), "VoltX 20000mAh", "#0891b2"),
    ("product-5.svg", headphones_glyph(), "SoundWave Pro", "#7c3aed"),
    ("product-6.svg", watch_glyph(), "PulseFit Watch", "#0f766e"),
    ("product-7.svg", airfryer_glyph(), "AeroCool Fryer", "#ea580c"),
    ("product-8.svg", tablet_glyph(), "Tab S9", "#2563eb"),
    ("product-9.svg", charger_glyph(), "RapidCharge 65W", "#9333ea"),
    ("product-10.svg", earbuds_glyph(), "BassBeat Buds", "#4f46e5"),
    ("product-11.svg", bulb_glyph(), "SmartBulb RGB", "#ca8a04"),
    ("product-12.svg", mouse_glyph(), "Gaming Mouse", "#0891b2"),
]

for name, glyph, label, tint in products:
    svg = open_svg(600, 600) + product_card(label, glyph, tint) + close_svg()
    with open(os.path.join(OUT, name), "w") as f:
        f.write(svg)

# favicon
svg = open_svg(480, 480) + bg_svg(480, 480, ("#ffffff", "#ffffff")) + favicon_glyph() + close_svg()
with open(os.path.join(OUT, "favicon.svg"), "w") as f:
    f.write(svg)

# placeholder
svg = open_svg(600, 600) + bg_svg(600, 600, ("#e2e8f0", "#cbd5e1"))
svg += text(300, 280, 70, "#64748b", "?", weight=800)
svg += text(300, 350, 28, "#64748b", "No image")
svg += close_svg()
with open(os.path.join(OUT, "placeholder.svg"), "w") as f:
    f.write(svg)

print("SVG assets generated:", len(os.listdir(OUT)))
