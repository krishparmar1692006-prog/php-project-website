-- ============================================================
-- TechCart E-Commerce Website - Database Schema & Seed Data
-- Course: Advanced Web Development in PHP (2010043347)
-- Assignment No: 2  |  Semester: V  |  Year: 2026-27
-- Run this file in phpMyAdmin (or MySQL CLI) BEFORE using the site
-- ============================================================

CREATE DATABASE IF NOT EXISTS techcart_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE techcart_db;

-- ------------------------------------------------------------
-- Users (customers)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  mobile VARCHAR(20) NOT NULL,
  password VARCHAR(255) NOT NULL,
  address VARCHAR(255) DEFAULT NULL,
  city VARCHAR(100) DEFAULT NULL,
  state VARCHAR(100) DEFAULT NULL,
  pincode VARCHAR(10) DEFAULT NULL,
  status TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1=active, 0=deactivated',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Admin users
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Categories
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  image VARCHAR(255) DEFAULT NULL,
  description TEXT DEFAULT NULL,
  status TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1=active, 0=hidden',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Products
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  name VARCHAR(200) NOT NULL,
  image VARCHAR(255) DEFAULT NULL,
  price DECIMAL(10,2) NOT NULL,
  discount_price DECIMAL(10,2) DEFAULT NULL,
  description TEXT DEFAULT NULL,
  specifications TEXT DEFAULT NULL,
  stock INT UNSIGNED NOT NULL DEFAULT 0,
  rating DECIMAL(2,1) NOT NULL DEFAULT 4.5 COMMENT '0.0 - 5.0',
  is_featured TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1=featured on home',
  status TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1=active, 0=hidden',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_product_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Orders
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(30) NOT NULL UNIQUE,
  user_id INT UNSIGNED NOT NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  mobile VARCHAR(20) NOT NULL,
  billing_address VARCHAR(255) NOT NULL,
  shipping_address VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state VARCHAR(100) NOT NULL,
  pincode VARCHAR(10) NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  payment_method VARCHAR(50) NOT NULL DEFAULT 'Cash on Delivery',
  payment_status VARCHAR(30) NOT NULL DEFAULT 'Unpaid',
  order_status VARCHAR(30) NOT NULL DEFAULT 'Pending',
  order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Order items (products inside an order)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  product_name VARCHAR(200) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  CONSTRAINT fk_item_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Contact / enquiry messages
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contact (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  mobile VARCHAR(20) DEFAULT NULL,
  subject VARCHAR(200) DEFAULT NULL,
  message TEXT NOT NULL,
  status TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=new, 1=read',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- SEED DATA
-- Default logins:
--   Customer : demo@techcart.com / password123
--   Admin    : admin / admin123   (visit /admin)
-- ============================================================

-- Admin account (password = admin123)
INSERT INTO admin (username, password, name) VALUES
('admin', '$2y$10$TYgvySiMkf7cAzuKJ.n8PuYa6zVeldByy7Cnz6vziGYJJyrcKv2XG', 'Store Administrator');

-- Demo customers (password = password123)
INSERT INTO users (name, email, mobile, password, address, city, state, pincode, status) VALUES
('Rahul Sharma', 'demo@techcart.com', '9876543210', '$2y$10$tj415eyfnDdu.wxT2wY9tev5hlbqJiezeZjpyxVL/5jHOXrefhV/C', '12 MG Road, Andheri East', 'Mumbai', 'Maharashtra', '400069', 1),
('Priya Patel', 'priya@example.com', '9123456780', '$2y$10$tj415eyfnDdu.wxT2wY9tev5hlbqJiezeZjpyxVL/5jHOXrefhV/C', '45 Lake View Apartments, HSR Layout', 'Bengaluru', 'Karnataka', '560102', 1);

-- Categories
INSERT INTO categories (name, image, description, status) VALUES
('Electronics', 'assets/images/cat-electronics.svg', 'Latest gadgets: smartphones, laptops, tablets and more.', 1),
('Mobile Accessories', 'assets/images/cat-accessories.svg', 'Cases, chargers, power banks, earphones and cables.', 1),
('Audio & Wearables', 'assets/images/cat-audio.svg', 'Headphones, smart watches, bluetooth speakers & earbuds.', 1),
('Home Appliances', 'assets/images/cat-home.svg', 'Smart home devices, kitchen appliances and lighting.', 1);

-- Products (images point to bundled SVG placeholders - replace via Admin Panel)
INSERT INTO products (category_id, name, image, price, discount_price, description, specifications, stock, rating, is_featured, status) VALUES
(1, 'Aurora X20 Smartphone', 'assets/images/product-1.svg', 24999.00, 21999.00, '6.7-inch AMOLED display, 108MP triple camera and a massive 5000mAh battery. Comes with 8GB RAM and 128GB storage.', 'Display: 6.7 AMOLED 120Hz | Camera: 108MP Triple | Battery: 5000mAh | RAM/ROM: 8/128GB', 25, 4.6, 1, 1),
(1, 'Nexa Laptop 14"', 'assets/images/product-2.svg', 52999.00, 49999.00, 'Ultrabook powered by an Intel Core i5 processor, 16GB RAM and 512GB NVMe SSD. Weighs just 1.4kg.', 'CPU: Core i5 | RAM: 16GB | SSD: 512GB NVMe | Display: 14 FHD IPS', 12, 4.7, 1, 1),
(2, 'ArmorPro Mobile Cover', 'assets/images/product-3.svg', 499.00, 399.00, 'Shockproof, 360-degree protection case with a raised bezel and anti-slip texture.', 'Material: TPU + PC | Compatible: Universal | Colour: Black', 150, 4.3, 0, 1),
(2, 'VoltX 20000mAh Power Bank', 'assets/images/product-4.svg', 1899.00, 1499.00, 'Dual USB output, fast charging support and LED power indicator. Charge two devices at once.', 'Capacity: 20000mAh | Output: 2xUSB | Fast Charge: 22.5W', 60, 4.5, 1, 1),
(3, 'SoundWave Pro Headphones', 'assets/images/product-5.svg', 3999.00, 3299.00, 'Active noise cancellation, 30-hour battery life and plush memory-foam ear cushions.', 'ANC: Yes | Battery: 30H | Bluetooth: 5.3 | Driver: 40mm', 40, 4.8, 1, 1),
(3, 'PulseFit Smart Watch', 'assets/images/product-6.svg', 2999.00, 2499.00, 'AMOLED display, heart-rate & SpO2 monitoring with 100+ sports modes and 7-day battery.', 'Display: 1.43 AMOLED | Battery: 7 Days | Water: 5ATM', 55, 4.4, 0, 1),
(4, 'AeroCool Smart Air Fryer', 'assets/images/product-7.svg', 7999.00, 6999.00, '5.5L capacity with 8 preset menus, digital touchscreen and rapid-air technology for oil-free cooking.', 'Capacity: 5.5L | Power: 1700W | Presets: 8', 18, 4.6, 1, 1),
(1, 'Tablet Tab S9 11"', 'assets/images/product-8.svg', 27999.00, 25999.00, 'Slim entertainment tablet with a 2K display, quad speakers and 4GB RAM for smooth multitasking.', 'Display: 11 2K | RAM: 4GB | Storage: 64GB | Battery: 8000mAh', 22, 4.5, 0, 1),
(2, 'RapidCharge 65W Adapter', 'assets/images/product-9.svg', 1299.00, 1099.00, 'Compact GaN fast charger with USB-C PD, charges a phone from 0 to 50% in about 30 minutes.', 'Output: 65W GaN | Ports: 1xUSB-C, 1xUSB-A', 80, 4.4, 0, 1),
(3, 'BassBeat Wireless Earbuds', 'assets/images/product-10.svg', 2499.00, 1999.00, 'True wireless earbuds with deep bass, touch controls and a pocket-sized charging case.', 'Battery: 24H w/ case | Bluetooth: 5.3 | IPX5', 90, 4.2, 0, 1),
(4, 'SmartBulb RGB LED Kit', 'assets/images/product-11.svg', 999.00, 799.00, 'Wi-Fi smart bulbs with 16 million colours, voice control and app scheduling. Pack of 2.', 'Bulbs: 2 | Power: 9W | Control: App + Voice', 70, 4.3, 0, 1),
(1, 'Gaming Mouse Phantom', 'assets/images/product-12.svg', 1499.00, 1199.00, 'Ergonomic RGB gaming mouse with 16000 DPI optical sensor and 6 programmable buttons.', 'DPI: 16000 | Buttons: 6 | RGB: Yes', 45, 4.7, 1, 1);
