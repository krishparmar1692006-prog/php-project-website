<?php
/**
 * CART PAGE - session-driven shopping cart with quantity controls.
 * Actions handled here: add / update / remove.
 */
require_once __DIR__ . '/includes/header.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';
$id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$qty    = isset($_GET['qty']) ? (int)$_GET['qty'] : 1;
$buyNow = isset($_GET['buynow']);
$addedQty = 0;

if ($action === 'add' && $id > 0) {
    // validate stock
    $stmt = $pdo->prepare('SELECT stock, status FROM products WHERE id=?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if ($row && $row['status'] == 1) {
        $inCart = isset($_SESSION['cart'][$id]) ? $_SESSION['cart'][$id] : 0;
        $addQty = min($row['stock'], max(1, $qty));
        $_SESSION['cart'][$id] = $inCart + $addQty;
        $addedQty = $addQty;
        if ($buyNow) {
            redirect('checkout.php');
        }
    }
    redirect('cart.php');
}
if ($action === 'update' && $id > 0) {
    updateCartItem($id, $qty);
    setFlash('success', 'Cart updated.');
    redirect('cart.php');
}
if ($action === 'remove' && $id > 0) {
    removeCartItem($id);
    setFlash('success', 'Product removed from cart.');
    redirect('cart.php');
}
if ($action === 'clear') {
    clearCart();
    setFlash('success', 'Cart cleared.');
    redirect('cart.php');
}

$data  = cartItemsWithDetails($pdo);
$items = $data['items'];
$total = $data['total'];
$pageTitle = 'Cart';
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item active">Shopping Cart</li>
  </ol></nav>
  <h3 class="section-title mb-4">Shopping Cart (<?php echo cartCount(); ?> items)</h3>

  <?php if ($addedQty): ?>
    <div class="alert alert-success">Added to cart successfully!</div>
  <?php endif; ?>

  <?php if (!$items): ?>
    <div class="text-center py-5">
      <i class="bi bi-cart-x display-1 text-muted"></i>
      <h5 class="mt-3">Your cart is empty</h5>
      <p class="text-muted">Browse our collection and add your favourite products.</p>
      <a href="products.php" class="btn btn-brand">Continue Shopping</a>
    </div>
  <?php else: ?>
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="table-responsive">
        <table class="table table-bordered table-cart align-middle bg-white">
          <thead><tr>
            <th>Product</th><th>Price</th><th>Qty</th><th>Total</th><th></th>
          </tr></thead>
          <tbody>
          <?php foreach ($items as $it):
              $p = $it['product']; ?>
            <tr>
              <td>
                <div class="d-flex align-items-center gap-3">
                  <img src="<?php echo img_url($p['image']); ?>" alt="<?php echo e($p['name']); ?>" style="width:64px;height:64px;object-fit:contain;background:#f1f5f9;border-radius:.5rem;">
                  <div>
                    <a href="product.php?id=<?php echo (int)$p['id']; ?>" class="fw-semibold text-decoration-none text-dark"><?php echo e($p['name']); ?></a>
                    <div class="small text-muted"><?php echo e($p['category_name'] ?? ''); ?></div>
                    <?php if ($p['stock'] < $it['quantity']): ?>
                      <div class="small text-danger">Only <?php echo (int)$p['stock']; ?> in stock</div>
                    <?php endif; ?>
                  </div>
                </div>
              </td>
              <td class="text-nowrap"><?php echo money($it['price']); ?></td>
              <td style="width:110px;">
                <form method="get" action="cart.php" class="d-flex align-items-center gap-1">
                  <input type="hidden" name="action" value="update">
                  <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                  <input type="number" name="qty" value="<?php echo (int)$it['quantity']; ?>" min="1" max="<?php echo max(1,(int)$p['stock']); ?>" class="form-control form-control-sm text-center">
                  <button class="btn btn-sm btn-brand-outline" title="Update"><i class="bi bi-arrow-repeat"></i></button>
                </form>
              </td>
              <td class="fw-bold text-nowrap"><?php echo money($it['line_total']); ?></td>
              <td><a href="cart.php?action=remove&id=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline-danger" title="Remove"><i class="bi bi-trash"></i></a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <a href="cart.php?action=clear" class="btn btn-outline-danger btn-sm"><i class="bi bi-cart-x me-1"></i>Clear Cart</a>
      <a href="products.php" class="btn btn-brand-outline btn-sm ms-2"><i class="bi bi-arrow-left me-1"></i>Continue Shopping</a>
    </div>
    <div class="col-lg-4">
      <div class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="fw-bold">Order Summary</h5>
          <hr>
          <div class="d-flex justify-content-between mb-2"><span>Subtotal</span><span class="fw-semibold"><?php echo money($total); ?></span></div>
          <div class="d-flex justify-content-between mb-2"><span>Delivery</span><span class="text-success">Free</span></div>
          <hr>
          <div class="d-flex justify-content-between fs-5 mb-3"><span class="fw-bold">Total</span><span class="fw-bold text-primary"><?php echo money($total); ?></span></div>
          <a href="checkout.php" class="btn btn-warning w-100"><i class="bi bi-credit-card me-1"></i>Proceed to Checkout</a>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
