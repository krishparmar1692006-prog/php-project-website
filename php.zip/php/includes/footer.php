<?php
/** Shared frontend footer + closing tags. */
if (!isset($BASE)) { $BASE = '.'; }
?>
</main>

<footer class="site-footer">
  <div class="container py-5">
    <div class="row g-4">
      <div class="col-md-4">
        <h5 class="fw-bold text-white mb-3"><i class="bi bi-cart4 me-1"></i>TechCart</h5>
        <p>Your one-stop online electronics store. We bring you the latest smartphones, laptops, accessories, audio gear and smart home appliances at the best prices with fast, reliable delivery.</p>
      </div>
      <div class="col-md-2">
        <h6 class="text-white fw-semibold mb-3">Quick Links</h6>
        <ul class="list-unstyled footer-links">
          <li><a href="<?php echo $BASE; ?>/index.php">Home</a></li>
          <li><a href="<?php echo $BASE; ?>/categories.php">Categories</a></li>
          <li><a href="<?php echo $BASE; ?>/products.php">Shop</a></li>
          <li><a href="<?php echo $BASE; ?>/about.php">About Us</a></li>
          <li><a href="<?php echo $BASE; ?>/contact.php">Contact Us</a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <h6 class="text-white fw-semibold mb-3">Customer Service</h6>
        <ul class="list-unstyled footer-links">
          <li><a href="<?php echo $BASE; ?>/cart.php">My Cart</a></li>
          <li><a href="<?php echo $BASE; ?>/orders.php">Order History</a></li>
          <li><a href="<?php echo $BASE; ?>/profile.php">My Account</a></li>
          <li><a href="<?php echo $BASE; ?>/register.php">Create Account</a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <h6 class="text-white fw-semibold mb-3">Contact Info</h6>
        <ul class="list-unstyled footer-links">
          <li><i class="bi bi-geo-alt me-2"></i>42 Cyber Park, Andheri East, Mumbai 400069</li>
          <li><i class="bi bi-telephone me-2"></i>+91 98765 43210</li>
          <li><i class="bi bi-envelope me-2"></i>support@techcart.in</li>
        </ul>
      </div>
    </div>
  </div>
  <div class="text-center py-3 border-top" style="border-color: rgba(255,255,255,.15) !important;">
    <small>&copy; <?php echo date('Y'); ?> TechCart &middot; Assignment No. 2 &middot; Advanced Web Development in PHP &middot; B.Tech (IT) Sem V</small>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $BASE; ?>/assets/js/main.js"></script>
</body>
</html>
