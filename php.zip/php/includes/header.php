<?php
/**
 * Shared frontend header (navbar + head). Every customer page includes this.
 * Sets $BASE to '.' so asset links work when the project is in any subfolder.
 */
require_once __DIR__ . '/config.php';
$BASE = '.';
$active = basename($_SERVER['PHP_SELF']);
$user = isLoggedIn() ? currentUser($pdo) : null;
$cartTotal = cartCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? e($pageTitle) . ' | ' : ''; ?>TechCart - Electronics Store</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="<?php echo $BASE; ?>/assets/css/style.css">
</head>
<body class="d-flex flex-column min-vh-100">

<nav class="navbar navbar-expand-lg site-header sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?php echo $BASE; ?>/index.php"><i class="bi bi-cart4 me-1"></i>Tech<span class="text-warning">Cart</span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link <?php echo $active === 'index.php' ? 'active' : ''; ?>" href="<?php echo $BASE; ?>/index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $active === 'categories.php' ? 'active' : ''; ?>" href="<?php echo $BASE; ?>/categories.php">Categories</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $active === 'products.php' ? 'active' : ''; ?>" href="<?php echo $BASE; ?>/products.php">Shop</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $active === 'about.php' ? 'active' : ''; ?>" href="<?php echo $BASE; ?>/about.php">About</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $active === 'contact.php' ? 'active' : ''; ?>" href="<?php echo $BASE; ?>/contact.php">Contact</a></li>
      </ul>
      <ul class="navbar-nav align-items-lg-center">
        <li class="nav-item me-lg-2">
          <a class="nav-link" href="<?php echo $BASE; ?>/cart.php"><i class="bi bi-cart3"></i> Cart
            <span class="badge bg-warning text-dark rounded-pill"><?php echo (int)$cartTotal; ?></span>
          </a>
        </li>
        <?php if ($user): ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="userMenu" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-person-circle me-1"></i><?php echo e($user['name']); ?>
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
            <li><a class="dropdown-item" href="<?php echo $BASE; ?>/profile.php"><i class="bi bi-person me-2"></i>My Profile</a></li>
            <li><a class="dropdown-item" href="<?php echo $BASE; ?>/orders.php"><i class="bi bi-box-seam me-2"></i>Order History</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?php echo $BASE; ?>/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
          </ul>
        </li>
        <?php else: ?>
        <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>/login.php"><i class="bi bi-box-arrow-in-right me-1"></i>Login</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>/register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<main class="flex-grow-1">
<?php echo renderFlash(); ?>
