<?php
/**
 * Shared helper functions: escaping, auth, flash messages, cart logic.
 */

/** HTML-escape a value before output */
function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/** Redirect and stop script execution */
function redirect($url)
{
    header('Location: ' . $url);
    exit;
}

/** Store a one-time flash message */
function setFlash($type, $message)
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

/** Retrieve (and clear) a flash message */
function getFlash()
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/** Render the bootstrap alert html for any flash message */
function renderFlash()
{
    $flash = getFlash();
    if (!$flash) {
        return '';
    }
    $type = $flash['type'] === 'error' ? 'danger' : $flash['type'];
    return '<div class="alert alert-' . e($type) . ' alert-dismissible fade show" role="alert">'
        . e($flash['message'])
        . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
}

/* ---------------- AUTH ---------------- */

function isLoggedIn()
{
    return !empty($_SESSION['user_id']);
}

function isAdminLoggedIn()
{
    return !empty($_SESSION['admin_id']);
}

function currentUser($pdo)
{
    if (!isLoggedIn()) {
        return null;
    }
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

/* ---------------- CART (PHP session based) ---------------- */

function cartItems()
{
    return isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
}

function addToCart($productId, $quantity = 1)
{
    $productId   = (int)$productId;
    $quantity    = max(1, (int)$quantity);
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] += $quantity;
    } else {
        $_SESSION['cart'][$productId] = $quantity;
    }
}

function updateCartItem($productId, $quantity)
{
    $productId = (int)$productId;
    $quantity  = (int)$quantity;
    if (!isset($_SESSION['cart'])) {
        return;
    }
    if ($quantity <= 0) {
        unset($_SESSION['cart'][$productId]);
    } else {
        $_SESSION['cart'][$productId] = $quantity;
    }
}

function removeCartItem($productId)
{
    if (isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]);
    }
}

function clearCart()
{
    $_SESSION['cart'] = [];
}

function cartCount()
{
    $count = 0;
    foreach (cartItems() as $quantity) {
        $count += $quantity;
    }
    return $count;
}

/**
 * Returns array with keys: items (each with product, quantity, price, line_total)
 * and total (grand total in INR). Only in-stock active products are kept.
 */
function cartItemsWithDetails($pdo)
{
    $items = [];
    $total = 0;
    foreach (cartItems() as $productId => $quantity) {
        $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ? AND status = 1');
        $stmt->execute([(int)$productId]);
        $product = $stmt->fetch();
        if ($product) {
            $price     = $product['discount_price'] > 0 ? (float)$product['discount_price'] : (float)$product['price'];
            $lineTotal = $price * $quantity;
            $total    += $lineTotal;
            $items[] = [
                'product'    => $product,
                'quantity'   => $quantity,
                'price'      => $price,
                'line_total' => $lineTotal,
            ];
        }
    }
    return ['items' => $items, 'total' => $total];
}

/** Effective selling price of a product row (discount if present) */
function sellingPrice($product)
{
    return $product['discount_price'] > 0 ? (float)$product['discount_price'] : (float)$product['price'];
}

/* ---------------- GENERIC FETCH HELPERS ---------------- */

function fetchCategories($pdo, $onlyActive = true)
{
    $sql = 'SELECT * FROM categories';
    if ($onlyActive) {
        $sql .= ' WHERE status = 1';
    }
    $sql .= ' ORDER BY name ASC';
    return $pdo->query($sql)->fetchAll();
}

function fetchProduct($pdo, $id)
{
    $stmt = $pdo->prepare('SELECT p.*, c.name AS category_name FROM products p
                           LEFT JOIN categories c ON c.id = p.category_id
                           WHERE p.id = ?');
    $stmt->execute([(int)$id]);
    return $stmt->fetch() ?: null;
}

function money($amount)
{
    return 'Rs. ' . number_format((float)$amount, 0);
}

/**
 * Build a correct URL for a stored asset path.
 * Works from both the root pages and the /admin pages via $SITE_ROOT.
 */
function img_url($path)
{
    global $BASE, $SITE_ROOT;
    $prefix = isset($SITE_ROOT) ? $SITE_ROOT : (isset($BASE) ? $BASE : '.');
    if (!$path) {
        return $prefix . '/assets/images/placeholder.svg';
    }
    // tolerate a stored path that already begins with ./ or assets/
    $path = ltrim($path, './');
    return $prefix . '/' . $path;
}

/** Human friendly date */
function niceDate($dt)
{
    return date('d M Y, h:i A', strtotime($dt));
}

/** Compute discount percentage between two prices */
function discountPercent($price, $discount)
{
    if ($discount <= 0 || $price <= 0) {
        return 0;
    }
    return round((($price - $discount) / $price) * 100);
}
