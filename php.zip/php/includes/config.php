<?php
/**
 * Central configuration file
 * Starts the session and loads database + helper functions.
 * Every page includes this file first.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
