<?php
/**
 * ORDER SUCCESS PAGE - shown right after a successful order placement.
 */
$pageTitle = 'Order Placed';
require_once __DIR__ . '/includes/header.php';

$orderId = $_SESSION['placedOrder'] ?? 0;
if (!$orderId || !isLoggedIn()) {
    redirect('products.php');
}

$stmt = $pdo->prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?');
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    redirect('orders.php');
}

$itemStmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ?');
$itemStmt->execute([$orderId]);
$orderItems = $itemStmt->fetchAll();

unset($_SESSION['placedOrder'], $_SESSION['placedTotal']);
?>
<div class="container py-5 text-center">
  <div class="mb-3"><i class="bi bi-check-circle-fill text-success" style="font-size:5rem;"></i></div>
  <h2 class="fw-bold">Order Placed Successfully! 🎉</h2>
  <p class="text-muted">Thank you for shopping with TechCart. Your order has been received and is being processed.</p>

  <div class="card border-0 shadow-sm mx-auto mt-4" style="max-width:760px;">
    <div class="card-body text-start p-4">
      <div class="row g-3 border-bottom pb-3 mb-3">
        <div class="col-md-4"><div class="small text-muted">Order ID</div><div class="fw-bold">#<?php echo e($order['order_number']); ?></div></div>
        <div class="col-md-4"><div class="small text-muted">Order Date</div><div class="fw-bold"><?php echo niceDate($order['order_date']); ?></div></div>
        <div class="col-md-4"><div class="small text-muted">Payment Method</div><div class="fw-bold"><?php echo e($order['payment_method']); ?></div></div>
      </div>

      <h6 class="fw-bold">Customer Information</h6>
      <p class="small mb-3"><?php echo e($order['name']); ?> &middot; <?php echo e($order['email']); ?> &middot; <?php echo e($order['mobile']); ?><br>
      <?php echo e($order['shipping_address']); ?>, <?php echo e($order['city']); ?>, <?php echo e($order['state']); ?> - <?php echo e($order['pincode']); ?></p>

      <h6 class="fw-bold">Ordered Products</h6>
      <table class="table table-sm table-bordered align-middle">
        <thead class="table-light"><tr><th>Product</th><th>Price</th><th>Qty</th><th class="text-end">Subtotal</th></tr></thead>
        <tbody>
        <?php foreach ($orderItems as $oi): ?>
          <tr>
            <td><?php echo e($oi['product_name']); ?></td>
            <td><?php echo money($oi['price']); ?></td>
            <td><?php echo (int)$oi['quantity']; ?></td>
            <td class="text-end"><?php echo money($oi['price'] * $oi['quantity']); ?></td>
          </tr>
        <?php endforeach; ?>
        <tr class="table-light"><td colspan="3" class="text-end fw-bold">Total Amount</td><td class="text-end fw-bold text-primary"><?php echo money($order['total_amount']); ?></td></tr>
        </tbody>
      </table>
      <p class="small text-muted mb-0">Payment Status: <span class="badge bg-secondary"><?php echo e($order['payment_status']); ?></span> &nbsp; Order Status: <span class="badge bg-info text-dark"><?php echo e($order['order_status']); ?></span></p>
    </div>
  </div>

  <div class="mt-4">
    <a href="products.php" class="btn btn-brand me-2"><i class="bi bi-bag me-1"></i>Continue Shopping</a>
    <a href="orders.php" class="btn btn-brand-outline"><i class="bi bi-box-seam me-1"></i>View Order History</a>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
