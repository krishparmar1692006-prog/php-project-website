<?php
/**
 * CONTACT US PAGE - contact info + form stored in the database.
 */
$pageTitle = 'Contact Us';
require_once __DIR__ . '/includes/header.php';

$errors = [];
$old = ['name'=>'','email'=>'','mobile'=>'','subject'=>'','message'=>''];
$sent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($old as $k => $v) {
        $old[$k] = trim($_POST[$k] ?? '');
    }
    if ($old['name'] === '') $errors['name'] = 'Name is required.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Valid email required.';
    if ($old['message'] === '') $errors['message'] = 'Message is required.';

    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO contact (name, email, mobile, subject, message) VALUES (?,?,?,?,?)');
        $stmt->execute([$old['name'], $old['email'], $old['mobile'], $old['subject'], $old['message']]);
        $sent = true;
    }
}
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item active">Contact Us</li>
  </ol></nav>
  <h3 class="section-title mb-4">Contact Us</h3>

  <?php if ($sent): ?>
    <div class="alert alert-success"><i class="bi bi-check-circle me-1"></i>Thank you! Your message has been sent. We will get back to you shortly.</div>
  <?php endif; ?>

  <div class="row g-4">
    <div class="col-md-5">
      <div class="card border-0 shadow-sm h-100">
        <div class="card-body p-4">
          <h5 class="fw-bold mb-3">Get in Touch</h5>
          <ul class="list-unstyled">
            <li class="mb-3"><i class="bi bi-geo-alt-fill text-primary me-2"></i>42 Cyber Park, Andheri East, Mumbai, Maharashtra 400069</li>
            <li class="mb-3"><i class="bi bi-telephone-fill text-primary me-2"></i><a href="tel:+919876543210" class="text-decoration-none">+91 98765 43210</a></li>
            <li class="mb-3"><i class="bi bi-envelope-fill text-primary me-2"></i><a href="mailto:support@techcart.in" class="text-decoration-none">support@techcart.in</a></li>
            <li class="mb-3"><i class="bi bi-clock-fill text-primary me-2"></i>Mon - Sat: 9:00 AM - 8:00 PM</li>
          </ul>
          <hr>
          <p class="small text-muted mb-0">We usually respond within 24 hours. For order-related questions, please include your Order ID.</p>
        </div>
      </div>
    </div>
    <div class="col-md-7">
      <form method="post" action="contact.php" class="card border-0 shadow-sm">
        <div class="card-body p-4">
          <h5 class="fw-bold mb-3">Send Us a Message</h5>
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label required">Your Name</label>
              <input type="text" name="name" class="form-control <?php echo isset($errors['name']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['name']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['name'] ?? ''); ?></div>
            </div>
            <div class="col-md-6">
              <label class="form-label required">Email</label>
              <input type="email" name="email" class="form-control <?php echo isset($errors['email']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['email']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['email'] ?? ''); ?></div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Mobile (optional)</label>
              <input type="text" name="mobile" class="form-control" value="<?php echo e($old['mobile']); ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Subject</label>
              <input type="text" name="subject" class="form-control" value="<?php echo e($old['subject']); ?>">
            </div>
            <div class="col-12">
              <label class="form-label required">Message</label>
              <textarea name="message" rows="5" class="form-control <?php echo isset($errors['message']) ? 'is-invalid' : ''; ?>"><?php echo e($old['message']); ?></textarea>
              <div class="invalid-feedback"><?php echo e($errors['message'] ?? ''); ?></div>
            </div>
          </div>
          <button type="submit" class="btn btn-brand mt-4"><i class="bi bi-send me-1"></i>Send Message</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
