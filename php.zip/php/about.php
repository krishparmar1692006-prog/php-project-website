<?php
/** ABOUT US PAGE - company, business concept, mission, vision. */
$pageTitle = 'About Us';
require_once __DIR__ . '/includes/header.php';
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item active">About Us</li>
  </ol></nav>
  <h3 class="section-title mb-4">About TechCart</h3>

  <div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-4">
      <h5 class="fw-bold text-primary"><i class="bi bi-shop me-2"></i>Our Store</h5>
      <p>TechCart is a dynamic online electronics store built as a full-stack academic project. We curate the latest smartphones, laptops, mobile accessories, audio &amp; wearables, and smart home appliances from trusted brands &mdash; all in one place, at transparent prices.</p>

      <div class="row g-4 mt-2">
        <div class="col-md-6">
          <div class="d-flex gap-3">
            <i class="bi bi-bullseye fs-2 text-primary"></i>
            <div>
              <h6 class="fw-bold mb-1">Our Mission</h6>
              <p class="text-muted mb-0">To make modern technology simple and affordable by delivering genuine products, honest pricing and fast delivery to every doorstep.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="d-flex gap-3">
            <i class="bi bi-eye fs-2 text-primary"></i>
            <div>
              <h6 class="fw-bold mb-1">Our Vision</h6>
              <p class="text-muted mb-0">To become a leading student-friendly e-commerce platform in India that demonstrates real-world web development and software engineering best practices.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="d-flex gap-3">
            <i class="bi bi-lightbulb fs-2 text-warning"></i>
            <div>
              <h6 class="fw-bold mb-1">Business Concept</h6>
              <p class="text-muted mb-0">A B2C retail model powered by PHP &amp; MySQL &mdash; featuring product catalogues, session-based shopping cart, order management, and a full administrative backend.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="d-flex gap-3">
            <i class="bi bi-box-seam fs-2 text-success"></i>
            <div>
              <h6 class="fw-bold mb-1">Products &amp; Services</h6>
              <p class="text-muted mb-0">Electronics, mobile accessories, audio and wearables, and home appliances &mdash; with free delivery, easy ordering and Cash on Delivery.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="row g-3 text-center">
    <div class="col-6 col-md-3"><div class="card border-0 shadow-sm"><div class="card-body"><h2 class="fw-bold text-primary">50+</h2><p class="text-muted mb-0">Products</p></div></div></div>
    <div class="col-6 col-md-3"><div class="card border-0 shadow-sm"><div class="card-body"><h2 class="fw-bold text-primary">4</h2><p class="text-muted mb-0">Categories</p></div></div></div>
    <div class="col-6 col-md-3"><div class="card border-0 shadow-sm"><div class="card-body"><h2 class="fw-bold text-primary">100%</h2><p class="text-muted mb-0">Secure Payments</p></div></div></div>
    <div class="col-6 col-md-3"><div class="card border-0 shadow-sm"><div class="card-body"><h2 class="fw-bold text-primary">24/7</h2><p class="text-muted mb-0">Support</p></div></div></div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
