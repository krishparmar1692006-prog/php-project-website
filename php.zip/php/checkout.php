<?php
/**
 * CHECKOUT PAGE
 * Requires login. Shows address form + order summary.
 * On submit it validates input and redirects to the payment page.
 */
$pageTitle = 'Checkout';
require_once __DIR__ . '/includes/header.php';

if (!isLoggedIn()) {
    setFlash('warning', 'Please log in to place your order.');
    redirect('login.php');
}

$data  = cartItemsWithDetails($pdo);
$items = $data['items'];
$total = $data['total'];

if (!$items) {
    setFlash('error', 'Your cart is empty.');
    redirect('cart.php');
}

// prefill from user profile
$profile = currentUser($pdo);
$errors  = [];
$old = [
  'name'    => $profile['name'],
  'email'   => $profile['email'],
  'mobile'  => $profile['mobile'],
  'billing' => $profile['address'],
  'shipping'=> $profile['address'],
  'city'    => $profile['city'],
  'state'   => $profile['state'],
  'pincode' => $profile['pincode'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (['name', 'email', 'mobile', 'billing', 'shipping', 'city', 'state', 'pincode'] as $f) {
        $old[$f] = trim($_POST[$f] ?? '');
    }
    if ($old['name'] === '')            $errors['name']    = 'Full name is required.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Valid email is required.';
    if (!preg_match('/^[0-9+\- ]{10,15}$/', $old['mobile'])) $errors['mobile'] = 'Valid mobile number required.';
    if ($old['billing'] === '')         $errors['billing'] = 'Billing address is required.';
    if ($old['shipping'] === '')        $errors['shipping'] = 'Shipping address is required.';
    if ($old['city'] === '')            $errors['city'] = 'City is required.';
    if ($old['state'] === '')           $errors['state'] = 'State is required.';
    if (!preg_match('/^\d{6}$/', $old['pincode'])) $errors['pincode'] = '6-digit pincode required.';

    if (!$errors) {
        // keep the entered data for the payment step (secure enough: no card data)
        $_SESSION['checkout'] = $old;
        $_SESSION['checkoutTotal'] = $total;
        redirect('payment.php');
    }
}
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="cart.php">Cart</a></li>
    <li class="breadcrumb-item active">Checkout</li>
  </ol></nav>
  <h3 class="section-title mb-4">Checkout</h3>

  <div class="row g-4">
    <div class="col-lg-7">
      <form method="post" action="checkout.php" class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="fw-bold mb-3">Delivery &amp; Billing Details</h5>
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label required">Full Name</label>
              <input type="text" name="name" class="form-control <?php echo isset($errors['name']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['name']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['name'] ?? ''); ?></div>
            </div>
            <div class="col-md-6">
              <label class="form-label required">Email</label>
              <input type="email" name="email" class="form-control <?php echo isset($errors['email']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['email']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['email'] ?? ''); ?></div>
            </div>
            <div class="col-md-6">
              <label class="form-label required">Mobile Number</label>
              <input type="text" name="mobile" class="form-control <?php echo isset($errors['mobile']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['mobile']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['mobile'] ?? ''); ?></div>
            </div>
            <div class="col-md-6">
              <label class="form-label required">Billing Address</label>
              <input type="text" name="billing" class="form-control <?php echo isset($errors['billing']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['billing']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['billing'] ?? ''); ?></div>
            </div>
            <div class="col-12">
              <label class="form-label required">Shipping Address</label>
              <input type="text" name="shipping" class="form-control <?php echo isset($errors['shipping']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['shipping']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['shipping'] ?? ''); ?></div>
            </div>
            <div class="col-md-4">
              <label class="form-label required">City</label>
              <input type="text" name="city" class="form-control <?php echo isset($errors['city']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['city']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['city'] ?? ''); ?></div>
            </div>
            <div class="col-md-4">
              <label class="form-label required">State</label>
              <input type="text" name="state" class="form-control <?php echo isset($errors['state']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['state']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['state'] ?? ''); ?></div>
            </div>
            <div class="col-md-4">
              <label class="form-label required">Pincode</label>
              <input type="text" name="pincode" class="form-control <?php echo isset($errors['pincode']) ? 'is-invalid' : ''; ?>" value="<?php echo e($old['pincode']); ?>">
              <div class="invalid-feedback"><?php echo e($errors['pincode'] ?? ''); ?></div>
            </div>
          </div>
          <button type="submit" class="btn btn-brand mt-4 w-100"><i class="bi bi-arrow-right-circle me-1"></i>Continue to Payment</button>
        </div>
      </form>
    </div>
    <div class="col-lg-5">
      <div class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="fw-bold">Order Summary (<?php echo cartCount(); ?> items)</h5>
          <hr>
          <?php foreach ($items as $it): ?>
            <div class="d-flex justify-content-between small mb-2">
              <span><?php echo e($it['product']['name']); ?> &times; <?php echo (int)$it['quantity']; ?></span>
              <span class="fw-semibold"><?php echo money($it['line_total']); ?></span>
            </div>
          <?php endforeach; ?>
          <hr>
          <div class="d-flex justify-content-between"><span>Subtotal</span><span><?php echo money($total); ?></span></div>
          <div class="d-flex justify-content-between mb-2"><span>Delivery</span><span class="text-success">Free</span></div>
          <div class="d-flex justify-content-between fs-5"><span class="fw-bold">Total</span><span class="fw-bold text-primary"><?php echo money($total); ?></span></div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
