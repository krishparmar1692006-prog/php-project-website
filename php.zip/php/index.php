<?php
/**
 * HOME PAGE
 * Dynamic hero banner, featured categories, featured products,
 * latest products and an offer strip - all fetched live from MySQL.
 */
$pageTitle = 'Home';
require_once __DIR__ . '/includes/header.php';

/* --- Dynamic data --- */
$categories   = fetchCategories($pdo, true);          // active categories
$featured     = $pdo->query('SELECT * FROM products WHERE status=1 AND is_featured=1 ORDER BY rating DESC LIMIT 8')->fetchAll();
$latest       = $pdo->query('SELECT * FROM products WHERE status=1 ORDER BY created_at DESC, id DESC LIMIT 8')->fetchAll();

/* Hero slides (static copy driven by the template - swap in banner images) */
$slides = [
  ['img' => 'assets/images/banner-1.svg', 'title' => 'Next-Gen Gadgets', 'sub' => 'Up to 40% off on smartphones, laptops & tablets.', 'btn' => 'Shop Electronics', 'link' => 'products.php?category=1'],
  ['img' => 'assets/images/banner-2.svg', 'title' => 'Audio & Wearables', 'sub' => 'ANC headphones, earbuds and smart watches on sale.', 'btn' => 'Explore Audio',   'link' => 'products.php?category=3'],
  ['img' => 'assets/images/banner-3.svg', 'title' => 'Smart Home Sale', 'sub' => 'Air fryers, smart bulbs & appliances at great prices.', 'btn' => 'Shop Appliances', 'link' => 'products.php?category=4'],
];
?>
<div class="container py-4">
  <!-- Hero / Banner slider -->
  <div id="heroCarousel" class="carousel slide hero-banner" data-bs-ride="carousel" data-bs-interval="4500">
    <div class="carousel-indicators">
      <?php foreach ($slides as $i => $s): ?>
        <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?php echo $i; ?>" class="<?php echo $i === 0 ? 'active' : ''; ?>" aria-current="<?php echo $i === 0 ? 'true' : 'false'; ?>"></button>
      <?php endforeach; ?>
    </div>
    <div class="carousel-inner">
      <?php foreach ($slides as $i => $s): ?>
      <div class="carousel-item <?php echo $i === 0 ? 'active' : ''; ?>">
        <img src="<?php echo $BASE; ?>/<?php echo $s['img']; ?>" class="d-block w-100" alt="<?php echo e($s['title']); ?>">
        <div class="carousel-caption d-none d-md-block hero-caption p-4">
          <h1 class="fw-bold"><?php echo e($s['title']); ?></h1>
          <p class="lead mb-3"><?php echo e($s['sub']); ?></p>
          <a href="<?php echo $s['link']; ?>" class="btn btn-warning"><?php echo e($s['btn']); ?></a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
  </div>

  <!-- Featured categories -->
  <div class="d-flex align-items-center justify-content-between mt-5 mb-4">
    <h3 class="section-title mb-0">Shop by Category</h3>
    <a href="categories.php" class="btn btn-brand-outline btn-sm">View all</a>
  </div>
  <div class="row g-3">
    <?php foreach ($categories as $cat): ?>
      <div class="col-6 col-md-3">
        <a class="category-card" href="products.php?category=<?php echo (int)$cat['id']; ?>">
          <img src="<?php echo img_url($cat['image']); ?>" alt="<?php echo e($cat['name']); ?>">
          <h6 class="mb-0"><?php echo e($cat['name']); ?></h6>
        </a>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Featured products -->
  <h3 class="section-title mt-5 mb-4">Featured Products</h3>
  <div class="row g-3">
    <?php foreach ($featured as $p):
        $price = sellingPrice($p); $pct = discountPercent($p['price'], $p['discount_price']); ?>
      <div class="col-6 col-md-3">
        <div class="product-card position-relative">
          <?php if ($pct > 0): ?><span class="discount-badge">-<?php echo $pct; ?>%</span><?php endif; ?>
          <div class="thumb"><img src="<?php echo img_url($p['image']); ?>" alt="<?php echo e($p['name']); ?>"></div>
          <div class="card-body p-3">
            <h6 class="card-title text-truncate mb-1"><a href="product.php?id=<?php echo (int)$p['id']; ?>" class="text-decoration-none text-dark"><?php echo e($p['name']); ?></a></h6>
            <div class="small text-muted mb-2"><i class="bi bi-star-fill text-warning"></i> <?php echo e($p['rating']); ?></div>
            <div class="product-price mb-2"><span class="price"><?php echo money($price); ?></span><?php if ($pct > 0): ?><span class="old-price"><?php echo money($p['price']); ?></span><?php endif; ?></div>
            <div class="d-grid gap-2">
              <a href="cart.php?action=add&id=<?php echo (int)$p['id']; ?>" class="btn btn-brand btn-sm"><i class="bi bi-cart-plus me-1"></i>Add to Cart</a>
              <a href="product.php?id=<?php echo (int)$p['id']; ?>" class="btn btn-brand-outline btn-sm">View Details</a>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Offer / promotional strip -->
  <div class="offer-strip p-4 mt-5 d-flex flex-wrap align-items-center justify-content-between">
    <div>
      <h4 class="mb-1 fw-bold">⚡ Mega Electronics Fest</h4>
      <p class="mb-0">Flat <strong>20% extra</strong> off on all audio gear with code <code class="text-warning">AUDIO20</code> &mdash; limited period!</p>
    </div>
    <a href="products.php" class="btn btn-light fw-semibold mt-2 mt-md-0">Grab the Deals</a>
  </div>

  <!-- New / latest products -->
  <h3 class="section-title mt-5 mb-4">New Arrivals</h3>
  <div class="row g-3">
    <?php foreach ($latest as $p):
        $price = sellingPrice($p); $pct = discountPercent($p['price'], $p['discount_price']); ?>
      <div class="col-6 col-md-3">
        <div class="product-card position-relative">
          <?php if ($pct > 0): ?><span class="discount-badge">-<?php echo $pct; ?>%</span><?php endif; ?>
          <div class="thumb"><img src="<?php echo img_url($p['image']); ?>" alt="<?php echo e($p['name']); ?>"></div>
          <div class="card-body p-3">
            <h6 class="card-title text-truncate mb-1"><a href="product.php?id=<?php echo (int)$p['id']; ?>" class="text-decoration-none text-dark"><?php echo e($p['name']); ?></a></h6>
            <div class="small text-muted mb-2"><i class="bi bi-star-fill text-warning"></i> <?php echo e($p['rating']); ?></div>
            <div class="product-price mb-2"><span class="price"><?php echo money($price); ?></span><?php if ($pct > 0): ?><span class="old-price"><?php echo money($p['price']); ?></span><?php endif; ?></div>
            <div class="d-grid gap-2">
              <a href="cart.php?action=add&id=<?php echo (int)$p['id']; ?>" class="btn btn-brand btn-sm"><i class="bi bi-cart-plus me-1"></i>Add to Cart</a>
              <a href="product.php?id=<?php echo (int)$p['id']; ?>" class="btn btn-brand-outline btn-sm">View Details</a>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
