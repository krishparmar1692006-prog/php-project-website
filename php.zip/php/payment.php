<?php
/**
 * PAYMENT PAGE
 * Supports Cash on Delivery (demo). Creates the order record on confirm.
 */
$pageTitle = 'Payment';
require_once __DIR__ . '/includes/header.php';

if (!isLoggedIn()) {
    setFlash('warning', 'Please log in to place your order.');
    redirect('login.php');
}
if (empty($_SESSION['checkout'])) {
    setFlash('error', 'Please complete checkout details first.');
    redirect('checkout.php');
}

$data     = cartItemsWithDetails($pdo);
$items    = $data['items'];
$total    = $data['total'];
$details  = $_SESSION['checkout'];

if (!$items) {
    setFlash('error', 'Your cart is empty.');
    redirect('cart.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $method = $_POST['payment_method'] ?? 'Cash on Delivery';
    $valid  = ['Cash on Delivery', 'UPI', 'Debit / Credit Card'];
    if (!in_array($method, $valid, true)) {
        setFlash('error', 'Invalid payment method.');
        redirect('payment.php');
    }

    try {
        $pdo->beginTransaction();

        // 1. Create the order
        $orderNumber = 'TC' . date('Ymd') . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        $payStatus   = ($method === 'Cash on Delivery') ? 'Unpaid' : 'Paid';
        $stmt = $pdo->prepare('INSERT INTO orders
            (order_number, user_id, name, email, mobile, billing_address, shipping_address, city, state, pincode, total_amount, payment_method, payment_status, order_status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, "Pending")');
        $stmt->execute([
            $orderNumber, $_SESSION['user_id'], $details['name'], $details['email'], $details['mobile'],
            $details['billing'], $details['shipping'], $details['city'], $details['state'], $details['pincode'],
            $total, $method, $payStatus,
        ]);
        $orderId = (int)$pdo->lastInsertId();

        // 2. Insert order items & decrement stock
        $stockStmt = $pdo->prepare('UPDATE products SET stock = stock - ? WHERE id = ?');
        $itemStmt  = $pdo->prepare('INSERT INTO order_items (order_id, product_id, product_name, price, quantity) VALUES (?,?,?,?,?)');
        foreach ($items as $it) {
            $p = $it['product'];
            $itemStmt->execute([$orderId, $p['id'], $p['name'], $it['price'], $it['quantity']]);
            $stockStmt->execute([$it['quantity'], $p['id']]);
        }

        $pdo->commit();

        // 3. Save the placed order for the success page, then clear the cart
        $_SESSION['placedOrder'] = $orderId;
        $_SESSION['placedTotal'] = $total;
        unset($_SESSION['checkout']);
        clearCart();
        redirect('order_success.php');
    } catch (Exception $ex) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        setFlash('error', 'Order could not be placed: ' . $ex->getMessage());
    }
}
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="cart.php">Cart</a></li>
    <li class="breadcrumb-item"><a href="checkout.php">Checkout</a></li>
    <li class="breadcrumb-item active">Payment</li>
  </ol></nav>
  <h3 class="section-title mb-4">Payment</h3>

  <div class="row g-4">
    <div class="col-lg-7">
      <form method="post" action="payment.php" class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="fw-bold mb-3"><i class="bi bi-credit-card me-2"></i>Choose Payment Method</h5>
          <div class="row g-3">
            <div class="col-md-4">
              <input type="radio" class="btn-check" name="payment_method" id="pmCod" value="Cash on Delivery" checked>
              <label class="btn btn-outline-primary w-100 py-3" for="pmCod">
                <i class="bi bi-cash-coin fs-3 d-block mb-1"></i>Cash on Delivery
              </label>
            </div>
            <div class="col-md-4">
              <input type="radio" class="btn-check" name="payment_method" id="pmUpi" value="UPI">
              <label class="btn btn-outline-primary w-100 py-3" for="pmUpi">
                <i class="bi bi-phone fs-3 d-block mb-1"></i>UPI
              </label>
            </div>
            <div class="col-md-4">
              <input type="radio" class="btn-check" name="payment_method" id="pmCard" value="Debit / Credit Card">
              <label class="btn btn-outline-primary w-100 py-3" for="pmCard">
                <i class="bi bi-credit-card-2-front fs-3 d-block mb-1"></i>Debit / Credit Card
              </label>
            </div>
          </div>
          <p class="text-muted small mt-3 mb-0"><i class="bi bi-info-circle me-1"></i>This is an academic project. "Cash on Delivery" is fully functional; other methods are simulated for demonstration.</p>
          <button type="submit" class="btn btn-warning mt-4 w-100 fw-semibold">
            <i class="bi bi-shield-check me-1"></i>Confirm &amp; Place Order &mdash; <?php echo money($total); ?>
          </button>
        </div>
      </form>
    </div>
    <div class="col-lg-5">
      <div class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="fw-bold">Summary</h5>
          <hr>
          <div class="small text-muted mb-1"><strong>Shipping to:</strong></div>
          <p class="small mb-2"><?php echo e($details['name']); ?>, <?php echo e($details['mobile']); ?><br><?php echo e($details['shipping']); ?><br><?php echo e($details['city']); ?>, <?php echo e($details['state']); ?> - <?php echo e($details['pincode']); ?></p>
          <hr>
          <div class="d-flex justify-content-between"><span>Items</span><span><?php echo cartCount(); ?></span></div>
          <div class="d-flex justify-content-between fs-5 mt-2"><span class="fw-bold">Total Payable</span><span class="fw-bold text-primary"><?php echo money($total); ?></span></div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
