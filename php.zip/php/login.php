<?php
/** LOGIN PAGE - customer authentication. */
$pageTitle = 'Login';
require_once __DIR__ . '/includes/header.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        if ($user['status'] != 1) {
            $errors[] = 'Your account has been deactivated. Contact support.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['user_name'] = $user['name'];
            $redirectTo = isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php';
            setFlash('success', 'Welcome back, ' . $user['name'] . '!');
            redirect($redirectTo);
        }
    } else {
        $errors[] = 'Invalid email or password.';
    }
}
?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
      <div class="card border-0 shadow-sm">
        <div class="card-body p-4 p-md-5">
          <div class="text-center mb-4">
            <i class="bi bi-person-circle display-4 text-primary"></i>
            <h4 class="fw-bold mt-2">Customer Login</h4>
            <p class="text-muted small">Sign in to continue shopping &amp; track orders</p>
          </div>
          <?php if ($errors): ?>
            <div class="alert alert-danger"><?php echo implode('<br>', array_map('e', $errors)); ?></div>
          <?php endif; ?>
          <form method="post" action="login.php<?php echo isset($_GET['redirect']) ? '?redirect=' . urlencode($_GET['redirect']) : ''; ?>">
            <div class="mb-3">
              <label class="form-label">Email Address</label>
              <input type="email" name="email" class="form-control" placeholder="you@example.com" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>
            <button type="submit" class="btn btn-brand w-100"><i class="bi bi-box-arrow-in-right me-1"></i>Login</button>
          </form>
          <hr>
          <p class="text-center small mb-0">New to TechCart? <a href="register.php">Create an account</a></p>
          <p class="text-center small text-muted mt-2 mb-0">Demo: demo@techcart.com / password123</p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
