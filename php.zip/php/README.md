# 🛒 TechCart — Dynamic E-Commerce Website (PHP + MySQL)

**Assignment No. 2 · Units 1–5**
**Institute:** College of Technology · **Programme:** B.Tech (IT) · **Semester:** V · **Year:** 2026–27
**Course:** Advanced Web Development in PHP (2010043347)

A fully dynamic e-commerce website built with **PHP, MySQL (PDO), Bootstrap 5** featuring a responsive customer frontend and a complete admin panel.

---

## ✨ Features

### Frontend (Customer Website)
- **Home page** — dynamic hero slider, featured categories, featured products, new arrivals, offer strip, footer
- **Category page** — all categories loaded from DB
- **Product listing page** — filter by category, search, sort (price/rating/newest), stock status, discount badges
- **Product detail page** — full info by product ID, specifications, quantity selector, Add to Cart & Buy Now
- **Cart page** — session-based cart with add/update/remove/clear, subtotal & total
- **Checkout page** — billing/shipping form with validation (login required)
- **Payment page** — Cash on Delivery (primary), plus UPI & Card (simulated)
- **Order success page** — Order ID, items, total, payment method, continue shopping
- **My Profile** — view/update all profile fields + password
- **Order History** — list + view details with live status badges
- **About Us** — mission, vision, business concept
- **Contact Us** — info + form stored in DB
- **Login / Register** — validation, secure `password_hash()` storage, session login

### Admin Panel (`/admin`)
- **Admin Login** — separate guarded authentication
- **Dashboard** — total users, categories, products, orders, revenue, contact messages; order-status breakdown; low-stock alerts; recent orders
- **Users** — list, search, edit, activate/deactivate, delete
- **Categories** — full CRUD + image upload + status toggle
- **Products** — full CRUD + image upload + stock management + featured/status toggle
- **Orders** — view all orders, order details, update order status & payment status

---

## 🔑 Default Logins

| Role     | URL          | Username / Email        | Password     |
|----------|--------------|-------------------------|--------------|
| Admin    | `/admin`     | `admin`                 | `admin123`   |
| Customer | `/login.php` | `demo@techcart.com`     | `password123`|

---

## 🚀 Setup Instructions (XAMPP / WAMP / LAMP)

1. **Install** [XAMPP](https://www.apachefriends.org/) (or any PHP + MySQL stack). Requires **PHP 7.4+** with `pdo_mysql` enabled.
2. **Copy the project** into your web root:
   - XAMPP (Windows): `C:\xampp\htdocs\techcart`
   - WAMP: `C:\wamp64\www\techcart`
   - Linux LAMP: `/var/www/html/techcart`
3. **Start Apache & MySQL** from the XAMPP Control Panel.
4. **Create the database:** open **phpMyAdmin** → go to the **Import** tab → choose **`database.sql`** → click **Go/Import**.
   This automatically creates the `techcart_db` database, all tables, and seed data.
5. **Configure DB credentials** (optional) — edit `includes/db.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'techcart_db');
   define('DB_USER', 'root');    // default XAMPP user
   define('DB_PASS', '');        // default XAMPP password is empty
   ```
6. **Open the site:**
   - Storefront → `http://localhost/techcart/`
   - Admin panel → `http://localhost/techcart/admin/`

> ⚠️ The `uploads/` folder needs write permission (`chmod 775` on Linux) for admin image uploads.

---

## 📁 Project Structure

```
techcart/
├── index.php                Home page (slider, categories, featured, new arrivals, offers)
├── categories.php           Category listing (dynamic)
├── products.php             Product listing (filter + search + sort)
├── product.php              Product detail page (by ID)
├── cart.php                 Shopping cart (session based)
├── checkout.php             Checkout (login required)
├── payment.php              Payment page + order creation
├── order_success.php        Order success confirmation
├── profile.php              Customer profile view/update
├── orders.php               Order history + details
├── about.php                About Us
├── contact.php              Contact Us (form stored in DB)
├── login.php / register.php Customer authentication
├── logout.php
├── database.sql             Schema + seed data (import this)
├── README.md
├── includes/
│   ├── config.php           Starts session + loads everything
│   ├── db.php               PDO connection
│   ├── functions.php        Helpers: auth, cart, escaping, images
│   ├── header.php / footer.php  Shared frontend layout
├── admin/
│   ├── index.php            Admin login
│   ├── dashboard.php        Statistics dashboard
│   ├── users.php            User management
│   ├── categories.php       Category CRUD
│   ├── products.php         Product CRUD + stock
│   ├── orders.php           Order management
│   ├── logout.php
│   └── includes/            auth guard, layout, upload helper
├── assets/
│   ├── css/style.css        Custom styles
│   ├── js/main.js           Small JS helpers
│   └── images/              SVG banners, category icons, product images, favicon
└── uploads/                 Admin image uploads (writable)
```

---

## 🗄️ Database Tables

`users` · `admin` · `categories` · `products` · `orders` · `order_items` · `contact`

All relationships use foreign keys; all PHP data access uses **PDO prepared statements**; passwords are stored with **bcrypt (`password_hash`)**.

---

## 📝 Note for Submission

This project demonstrates: CRUD operations, authentication & sessions, secure password hashing, shopping cart logic, order lifecycle management, an admin dashboard with statistics, dynamic frontend rendering, and image upload — covering all the required assignment points for Units 1–5.
