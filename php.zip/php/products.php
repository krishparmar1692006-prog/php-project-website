<?php
/**
 * PRODUCT LISTING PAGE
 * Shows products (optionally filtered by category), with search & sort.
 */
$pageTitle = 'Shop';
require_once __DIR__ . '/includes/header.php';

$categoryId = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$searchTxt  = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort       = isset($_GET['sort']) ? $_GET['sort'] : 'newest';

$where    = ['p.status = 1'];
$params   = [];
if ($categoryId > 0) {
    $where[] = 'p.category_id = ?';
    $params[] = $categoryId;
}
if ($searchTxt !== '') {
    $where[] = '(p.name LIKE ? OR p.description LIKE ?)';
    $params[] = '%' . $searchTxt . '%';
    $params[] = '%' . $searchTxt . '%';
}
$orderMap = [
  'newest'  => 'p.created_at DESC, p.id DESC',
  'price_asc'  => 'IFNULL(p.discount_price,p.price) ASC',
  'price_desc' => 'IFNULL(p.discount_price,p.price) DESC',
  'rating'  => 'p.rating DESC',
  'name'    => 'p.name ASC',
];
$orderBy = isset($orderMap[$sort]) ? $orderMap[$sort] : $orderMap['newest'];

$sql = 'SELECT p.*, c.name AS category_name FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        WHERE ' . implode(' AND ', $where) . ' ORDER BY ' . $orderBy;
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$chosenCat = null;
if ($categoryId > 0) {
    $c = $pdo->prepare('SELECT * FROM categories WHERE id = ?');
    $c->execute([$categoryId]);
    $chosenCat = $c->fetch();
}
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item"><a href="categories.php">Categories</a></li>
    <li class="breadcrumb-item active"><?php echo e($chosenCat ? $chosenCat['name'] : 'All Products'); ?></li>
  </ol></nav>

  <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
    <h3 class="section-title mb-0"><?php echo e($chosenCat ? $chosenCat['name'] . ' (' . count($products) . ')' : 'All Products (' . count($products) . ')'); ?></h3>
    <div class="d-flex gap-2">
      <form class="d-flex" method="get" action="products.php">
        <?php if ($categoryId): ?><input type="hidden" name="category" value="<?php echo $categoryId; ?>"><?php endif; ?>
        <input class="form-control form-control-sm me-2" type="search" name="search" placeholder="Search products..." value="<?php echo e($searchTxt); ?>">
        <button class="btn btn-brand btn-sm" type="submit"><i class="bi bi-search"></i></button>
      </form>
      <select class="form-select form-select-sm w-auto" onchange="location.href='?<?php echo $categoryId ? 'category='.$categoryId.'&' : ''; ?>sort='+this.value;">
        <option value="newest" <?php echo $sort==='newest'?'selected':''; ?>>Newest</option>
        <option value="price_asc" <?php echo $sort==='price_asc'?'selected':''; ?>>Price: Low to High</option>
        <option value="price_desc" <?php echo $sort==='price_desc'?'selected':''; ?>>Price: High to Low</option>
        <option value="rating" <?php echo $sort==='rating'?'selected':''; ?>>Top Rated</option>
        <option value="name" <?php echo $sort==='name'?'selected':''; ?>>Name A-Z</option>
      </select>
    </div>
  </div>

  <div class="row g-3">
    <?php if (!$products): ?>
      <div class="col-12"><div class="alert alert-warning">No products found. Try a different category or search term.</div></div>
    <?php endif; ?>
    <?php foreach ($products as $p):
        $price = sellingPrice($p); $pct = discountPercent($p['price'], $p['discount_price']); ?>
      <div class="col-6 col-md-4 col-lg-3">
        <div class="product-card position-relative">
          <?php if ($pct > 0): ?><span class="discount-badge">-<?php echo $pct; ?>%</span><?php endif; ?>
          <div class="thumb"><img src="<?php echo img_url($p['image']); ?>" alt="<?php echo e($p['name']); ?>"></div>
          <div class="card-body p-3">
            <span class="badge bg-light text-muted mb-1"><?php echo e($p['category_name']); ?></span>
            <h6 class="card-title text-truncate mb-1"><a href="product.php?id=<?php echo (int)$p['id']; ?>" class="text-decoration-none text-dark"><?php echo e($p['name']); ?></a></h6>
            <div class="small text-muted mb-2"><i class="bi bi-star-fill text-warning"></i> <?php echo e($p['rating']); ?> &middot; <span class="text-success"><?php echo $p['stock'] > 0 ? 'In Stock (' . (int)$p['stock'] . ')' : 'Out of Stock'; ?></span></div>
            <div class="product-price mb-2"><span class="price"><?php echo money($price); ?></span><?php if ($pct > 0): ?><span class="old-price"><?php echo money($p['price']); ?></span><?php endif; ?></div>
            <div class="d-grid gap-2">
              <a href="cart.php?action=add&id=<?php echo (int)$p['id']; ?>" class="btn btn-brand btn-sm"><i class="bi bi-cart-plus me-1"></i>Add to Cart</a>
              <a href="product.php?id=<?php echo (int)$p['id']; ?>" class="btn btn-brand-outline btn-sm">View Details</a>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
