<?php
/**
 * ADMIN CATEGORIES - full CRUD (add / view / edit / delete + status).
 */
$pageTitle = 'Categories';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/upload.php';

/* --- Handle actions --- */
if (isset($_GET['action'])) {
    $act = $_GET['action'];
    if ($act === 'delete' && isset($_GET['id'])) {
        $pdo->prepare('DELETE FROM categories WHERE id=?')->execute([(int)$_GET['id']]);
        setFlash('success', 'Category deleted.');
        header('Location: categories.php'); exit;
    }
    if ($act === 'toggle' && isset($_GET['id'])) {
        $c = $pdo->query('SELECT status FROM categories WHERE id=' . (int)$_GET['id'])->fetch();
        if ($c) {
            $pdo->prepare('UPDATE categories SET status=? WHERE id=?')->execute([$c['status'] ? 0 : 1, (int)$_GET['id']]);
        }
        header('Location: categories.php'); exit;
    }
}

/* --- Save (add / edit) --- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_category'])) {
    $id          = (int)($_POST['id'] ?? 0);
    $name        = trim($_POST['name']);
    $description = trim($_POST['description']);
    $status      = isset($_POST['status']) ? 1 : 0;
    $err         = '';
    $imagePath   = handleImageUpload('image', $err);

    if ($name === '') {
        setFlash('error', 'Category name is required.');
        header('Location: categories.php'); exit;
    }
    if ($err) {
        setFlash('error', $err);
        header('Location: categories.php'); exit;
    }

    if ($id > 0) {
        if ($imagePath !== '') {
            $pdo->prepare('UPDATE categories SET name=?, image=?, description=?, status=? WHERE id=?')
                ->execute([$name, $imagePath, $description, $status, $id]);
        } else {
            $pdo->prepare('UPDATE categories SET name=?, description=?, status=? WHERE id=?')
                ->execute([$name, $description, $status, $id]);
        }
        setFlash('success', 'Category updated.');
    } else {
        $pdo->prepare('INSERT INTO categories (name, image, description, status) VALUES (?,?,?,?)')
            ->execute([$name, $imagePath, $description, $status]);
        setFlash('success', 'Category added.');
    }
    header('Location: categories.php'); exit;
}

/* --- Edit target --- */
$editCat = null;
if (isset($_GET['edit'])) {
    $ec = $pdo->prepare('SELECT * FROM categories WHERE id=?');
    $ec->execute([(int)$_GET['edit']]);
    $editCat = $ec->fetch();
}

$categories = $pdo->query('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) AS products
                           FROM categories c ORDER BY c.id DESC')->fetchAll();
?>
<div class="row g-4">
  <div class="col-lg-4">
    <div class="card border-0 shadow-sm">
      <div class="card-body">
        <h5 class="fw-bold mb-3"><?php echo $editCat ? 'Edit Category' : 'Add New Category'; ?></h5>
        <form method="post" action="categories.php" enctype="multipart/form-data">
          <input type="hidden" name="save_category" value="1">
          <input type="hidden" name="id" value="<?php echo $editCat ? (int)$editCat['id'] : 0; ?>">
          <div class="mb-3">
            <label class="form-label required">Category Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo $editCat ? e($editCat['name']) : ''; ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" rows="3" class="form-control"><?php echo $editCat ? e($editCat['description']) : ''; ?></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Image</label>
            <input type="file" name="image" class="form-control" accept="image/*">
            <?php if ($editCat && $editCat['image']): ?>
              <div class="mt-2"><img src="<?php echo img_url($editCat['image']); ?>" style="width:60px;height:60px;object-fit:contain;border:1px solid #ddd;border-radius:.5rem;"></div>
            <?php endif; ?>
          </div>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" name="status" id="cStatus" <?php echo (!$editCat || $editCat['status']) ? 'checked' : ''; ?>>
            <label class="form-check-label" for="cStatus">Active (visible on website)</label>
          </div>
          <button class="btn btn-primary w-100"><i class="bi bi-save me-1"></i><?php echo $editCat ? 'Update Category' : 'Add Category'; ?></button>
          <?php if ($editCat): ?><a href="categories.php" class="btn btn-outline-secondary w-100 mt-2">Cancel</a><?php endif; ?>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card border-0 shadow-sm">
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
            <tr><th>ID</th><th>Image</th><th>Name</th><th>Products</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
          <?php if (!$categories): ?><tr><td colspan="6" class="text-center text-muted py-4">No categories yet.</td></tr><?php endif; ?>
          <?php foreach ($categories as $cat): ?>
            <tr>
              <td><?php echo (int)$cat['id']; ?></td>
              <td><img src="<?php echo img_url($cat['image']); ?>" style="width:48px;height:48px;object-fit:contain;background:#f1f5f9;border-radius:.4rem;"></td>
              <td class="fw-semibold"><?php echo e($cat['name']); ?></td>
              <td><span class="badge bg-primary"><?php echo (int)$cat['products']; ?></span></td>
              <td><span class="badge <?php echo $cat['status'] ? 'bg-success' : 'bg-secondary'; ?>"><?php echo $cat['status'] ? 'Active' : 'Hidden'; ?></span></td>
              <td>
                <a href="categories.php?edit=<?php echo (int)$cat['id']; ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                <a href="categories.php?action=toggle&id=<?php echo (int)$cat['id']; ?>" class="btn btn-sm btn-outline-warning" title="Toggle status"><i class="bi bi-eye-slash"></i></a>
                <a href="categories.php?action=delete&id=<?php echo (int)$cat['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this category and its products?')"><i class="bi bi-trash"></i></a>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
