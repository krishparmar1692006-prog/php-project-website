<?php
/**
 * ADMIN PRODUCTS - full CRUD (add / view / edit / delete / status / stock).
 */
$pageTitle = 'Products';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/upload.php';

/* --- Actions --- */
if (isset($_GET['action'], $_GET['id'])) {
    $pid = (int)$_GET['id'];
    if ($_GET['action'] === 'delete') {
        $pdo->prepare('DELETE FROM products WHERE id=?')->execute([$pid]);
        setFlash('success', 'Product deleted.');
        header('Location: products.php'); exit;
    }
    if ($_GET['action'] === 'toggle') {
        $pr = $pdo->query('SELECT status FROM products WHERE id=' . $pid)->fetch();
        if ($pr) {
            $pdo->prepare('UPDATE products SET status=? WHERE id=?')->execute([$pr['status'] ? 0 : 1, $pid]);
        }
        header('Location: products.php'); exit;
    }
    if ($_GET['action'] === 'feature') {
        $pr = $pdo->query('SELECT is_featured FROM products WHERE id=' . $pid)->fetch();
        if ($pr) {
            $pdo->prepare('UPDATE products SET is_featured=? WHERE id=?')->execute([$pr['is_featured'] ? 0 : 1, $pid]);
        }
        header('Location: products.php'); exit;
    }
}

/* --- Quick stock update (inline form on the list) --- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quick_stock'])) {
    $pid  = (int)$_POST['quick_stock'];
    $qty  = max(0, (int)($_POST['stock_val'] ?? 0));
    $pdo->prepare('UPDATE products SET stock=? WHERE id=?')->execute([$qty, $pid]);
    setFlash('success', 'Stock updated for product #' . $pid . '.', 'error');
    header('Location: products.php'); exit;
}

/* --- Save product --- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_product'])) {
    $id          = (int)($_POST['id'] ?? 0);
    $category_id = (int)$_POST['category_id'];
    $name        = trim($_POST['name']);
    $price       = (float)$_POST['price'];
    $discount    = !empty($_POST['discount_price']) ? (float)$_POST['discount_price'] : 0;
    $description = trim($_POST['description']);
    $specs       = trim($_POST['specifications']);
    $stock       = (int)$_POST['stock'];
    $rating      = (float)($_POST['rating'] ?? 4.5);
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;
    $status      = isset($_POST['status']) ? 1 : 0;
    $err         = '';
    $imagePath   = handleImageUpload('image', $err);

    if ($name === '' || $category_id <= 0 || $price <= 0) {
        setFlash('error', 'Name, category and a valid price are required.');
        header('Location: products.php'); exit;
    }
    if ($err) {
        setFlash('error', $err);
        header('Location: products.php'); exit;
    }

    if ($id > 0) {
        if ($imagePath !== '') {
            $pdo->prepare('UPDATE products SET category_id=?, name=?, image=?, price=?, discount_price=?, description=?, specifications=?, stock=?, rating=?, is_featured=?, status=? WHERE id=?')
                ->execute([$category_id, $name, $imagePath, $price, $discount, $description, $specs, $stock, $rating, $is_featured, $status, $id]);
        } else {
            $pdo->prepare('UPDATE products SET category_id=?, name=?, price=?, discount_price=?, description=?, specifications=?, stock=?, rating=?, is_featured=?, status=? WHERE id=?')
                ->execute([$category_id, $name, $price, $discount, $description, $specs, $stock, $rating, $is_featured, $status, $id]);
        }
        setFlash('success', 'Product updated.');
    } else {
        $pdo->prepare('INSERT INTO products (category_id, name, image, price, discount_price, description, specifications, stock, rating, is_featured, status)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([$category_id, $name, $imagePath, $price, $discount, $description, $specs, $stock, $rating, $is_featured, $status]);
        setFlash('success', 'Product added.');
    }
    header('Location: products.php'); exit;
}

/* --- Edit target --- */
$editProduct = null;
if (isset($_GET['edit'])) {
    $ep = $pdo->prepare('SELECT * FROM products WHERE id=?');
    $ep->execute([(int)$_GET['edit']]);
    $editProduct = $ep->fetch();
}

$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$qFilter = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$qSearch = isset($_GET['search']) ? trim($_GET['search']) : '';

$sql = 'SELECT p.*, c.name AS cat_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE 1';
$params = [];
if ($qFilter) { $sql .= ' AND p.category_id=?'; $params[] = $qFilter; }
if ($qSearch) { $sql .= ' AND p.name LIKE ?'; $params[] = '%'.$qSearch.'%'; }
$sql .= ' ORDER BY p.id DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
?>
<div class="d-flex flex-wrap gap-2 mb-4">
  <a href="products.php?new=1" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Add Product</a>
  <form class="d-flex ms-auto" method="get" action="products.php">
    <select name="cat" class="form-select form-select-sm me-2 w-auto" onchange="this.form.submit()">
      <option value="0">All Categories</option>
      <?php foreach ($categories as $c): ?>
        <option value="<?php echo (int)$c['id']; ?>" <?php echo $qFilter === (int)$c['id'] ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option>
      <?php endforeach; ?>
    </select>
    <input type="search" name="search" class="form-control form-control-sm me-2" placeholder="Search product..." value="<?php echo e($qSearch); ?>">
    <button class="btn btn-sm btn-primary"><i class="bi bi-search"></i></button>
  </form>
</div>

<div class="card border-0 shadow-sm">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr><th>ID</th><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Discount</th><th>Stock</th><th>Rating</th><th>Status</th><th>Actions</th></tr>
      </thead>
      <tbody>
      <?php if (!$products): ?><tr><td colspan="10" class="text-center text-muted py-4">No products found.</td></tr><?php endif; ?>
      <?php foreach ($products as $p): ?>
        <tr>
          <td><?php echo (int)$p['id']; ?></td>
          <td><img src="<?php echo img_url($p['image']); ?>" style="width:48px;height:48px;object-fit:contain;background:#f1f5f9;border-radius:.4rem;"></td>
          <td class="fw-semibold"><?php echo e($p['name']); ?>
            <?php if ($p['is_featured']): ?><span class="badge bg-warning text-dark ms-1">★</span><?php endif; ?>
          </td>
          <td><?php echo e($p['cat_name'] ?: '-'); ?></td>
          <td class="text-nowrap text-decoration-line-through text-muted small"><?php echo money($p['price']); ?></td>
          <td class="text-nowrap fw-bold text-success"><?php echo $p['discount_price'] ? money($p['discount_price']) : '-'; ?></td>
          <td>
            <form method="post" action="products.php" class="d-inline-flex align-items-center gap-1">
              <input type="hidden" name="quick_stock" value="<?php echo (int)$p['id']; ?>">
              <input type="number" name="stock_val" value="<?php echo (int)$p['stock']; ?>" min="0" style="width:70px;" class="form-control form-control-sm">
              <button class="btn btn-sm btn-outline-success" title="Update stock"><i class="bi bi-check2"></i></button>
            </form>
          </td>
          <td><?php echo e($p['rating']); ?></td>
          <td><span class="badge <?php echo $p['status'] ? 'bg-success' : 'bg-secondary'; ?>"><?php echo $p['status'] ? 'Active' : 'Hidden'; ?></span></td>
          <td class="text-nowrap">
            <a href="products.php?edit=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
            <a href="products.php?action=feature&id=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline-warning" title="Toggle featured"><i class="bi bi-star"></i></a>
            <a href="products.php?action=toggle&id=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline-info" title="Toggle status"><i class="bi bi-eye-slash"></i></a>
            <a href="products.php?action=delete&id=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this product?')"><i class="bi bi-trash"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if (isset($_GET['new']) || $editProduct): ?>
<?php $e = $editProduct; ?>
<div class="modal fade show d-block" tabindex="-1" style="background:rgba(0,0,0,.5);">
  <div class="modal-dialog modal-lg">
    <form method="post" action="products.php" enctype="multipart/form-data" class="modal-content">
      <input type="hidden" name="save_product" value="1">
      <input type="hidden" name="id" value="<?php echo $e ? (int)$e['id'] : 0; ?>">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title"><?php echo $e ? 'Edit Product #' . (int)$e['id'] : 'Add New Product'; ?></h5>
        <a href="products.php" class="btn-close btn-close-white"></a>
      </div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label required">Product Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo $e ? e($e['name']) : ''; ?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label required">Category</label>
            <select name="category_id" class="form-select" required>
              <option value="">-- Select --</option>
              <?php foreach ($categories as $c): ?>
                <option value="<?php echo (int)$c['id']; ?>" <?php echo ($e && (int)$e['category_id'] === (int)$c['id']) ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label required">Price (Rs.)</label>
            <input type="number" step="0.01" min="0" name="price" class="form-control" value="<?php echo $e ? e($e['price']) : ''; ?>" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Discount Price (Rs.)</label>
            <input type="number" step="0.01" min="0" name="discount_price" class="form-control" value="<?php echo $e && $e['discount_price'] ? e($e['discount_price']) : ''; ?>">
          </div>
          <div class="col-md-4">
            <label class="form-label required">Stock Quantity</label>
            <input type="number" min="0" name="stock" class="form-control" value="<?php echo $e ? (int)$e['stock'] : 0; ?>" required>
          </div>
          <div class="col-12">
            <label class="form-label">Description</label>
            <textarea name="description" rows="3" class="form-control"><?php echo $e ? e($e['description']) : ''; ?></textarea>
          </div>
          <div class="col-12">
            <label class="form-label">Specifications <span class="text-muted small">(separate with |)</span></label>
            <input type="text" name="specifications" class="form-control" placeholder="e.g. RAM: 8GB | Display: 6.7 | Battery: 5000mAh" value="<?php echo $e ? e($e['specifications']) : ''; ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Image</label>
            <input type="file" name="image" class="form-control" accept="image/*">
            <?php if ($e && $e['image']): ?>
              <div class="mt-2"><img src="<?php echo img_url($e['image']); ?>" style="width:60px;height:60px;object-fit:contain;border:1px solid #ddd;border-radius:.5rem;"></div>
            <?php endif; ?>
          </div>
          <div class="col-md-6">
            <label class="form-label">Rating (0-5)</label>
            <input type="number" step="0.1" min="0" max="5" name="rating" class="form-control" value="<?php echo $e ? e($e['rating']) : '4.5'; ?>">
            <div class="form-check form-switch mt-3">
              <input class="form-check-input" type="checkbox" name="is_featured" id="pFeat" <?php echo ($e && $e['is_featured']) ? 'checked' : ''; ?>>
              <label class="form-check-label" for="pFeat">Featured on home page</label>
            </div>
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" name="status" id="pStatus" <?php echo (!$e || $e['status']) ? 'checked' : ''; ?>>
              <label class="form-check-label" for="pStatus">Active (visible)</label>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <a href="products.php" class="btn btn-secondary">Cancel</a>
        <button class="btn btn-primary"><i class="bi bi-save me-1"></i><?php echo $e ? 'Update' : 'Add'; ?> Product</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
