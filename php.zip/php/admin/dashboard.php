<?php
/** ADMIN DASHBOARD - statistics overview. */
$pageTitle = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

$stats = [
    'users'      => (int)$pdo->query('SELECT COUNT(*) c FROM users')->fetch()['c'],
    'categories' => (int)$pdo->query('SELECT COUNT(*) c FROM categories')->fetch()['c'],
    'products'   => (int)$pdo->query('SELECT COUNT(*) c FROM products')->fetch()['c'],
    'orders'     => (int)$pdo->query('SELECT COUNT(*) c FROM orders')->fetch()['c'],
    'revenue'    => (float)$pdo->query('SELECT COALESCE(SUM(total_amount),0) s FROM orders WHERE order_status <> "Cancelled"')->fetch()['s'],
    'contact'    => (int)$pdo->query('SELECT COUNT(*) c FROM contact WHERE status=0')->fetch()['c'],
];

$statusCounts = $pdo->query('SELECT order_status, COUNT(*) c FROM orders GROUP BY order_status')->fetchAll();
$statusMap = [];
foreach ($statusCounts as $sc) { $statusMap[$sc['order_status']] = (int)$sc['c']; }

$recentOrders = $pdo->query('SELECT o.*, u.name AS customer FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 6')->fetchAll();
$lowStock     = $pdo->query('SELECT * FROM products WHERE stock <= 5 ORDER BY stock ASC LIMIT 6')->fetchAll();

$cardColors = [
  ['users','bi-people','primary','rgb(37,99,235)','rgb(59,130,246)'],
  ['categories','bi-tags','warning','rgb(245,158,11)','rgb(251,191,36)'],
  ['products','bi-box-seam','success','rgb(22,163,74)','rgb(34,197,94)'],
  ['orders','bi-cart-check','info','rgb(8,145,178)','rgb(6,182,212)'],
  ['revenue','bi-currency-rupee','success','rgb(16,185,129)','rgb(52,211,153)'],
  ['contact','bi-envelope','danger','rgb(220,38,38)','rgb(239,68,68)'],
];
$statusDot = ['Pending'=>'secondary','Confirmed'=>'primary','Processing'=>'info','Shipped'=>'warning','Delivered'=>'success','Cancelled'=>'danger'];
?>
<div class="row g-3 mb-4">
  <?php foreach ($cardColors as $c):
      $key = $c[0]; $label = ucfirst($key);?>
    <div class="col-6 col-xl-3">
      <div class="card stat-card" style="background:linear-gradient(135deg, <?php echo $c[3]; ?>, <?php echo $c[4]; ?>);">
        <div class="card-body d-flex align-items-center justify-content-between">
          <div>
            <div class="small opacity-75"><?php echo $label; ?></div>
            <div class="fs-3 fw-bold"><?php echo $key === 'revenue' ? 'Rs. ' . number_format($stats['revenue']) : number_format($stats[$key]); ?></div>
          </div>
          <i class="bi <?php echo $c[2]; ?>"></i>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="card border-0 shadow-sm">
      <div class="card-header bg-white fw-bold">Recent Orders</div>
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light"><tr><th>#Order</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th></tr></thead>
          <tbody>
          <?php if (!$recentOrders): ?>
            <tr><td colspan="5" class="text-center text-muted py-4">No orders yet.</td></tr>
          <?php endif; ?>
          <?php foreach ($recentOrders as $o): ?>
            <tr>
              <td class="fw-semibold">#<?php echo e($o['order_number']); ?></td>
              <td><?php echo e($o['customer']); ?></td>
              <td><?php echo date('d M Y', strtotime($o['order_date'])); ?></td>
              <td class="fw-bold"><?php echo money($o['total_amount']); ?></td>
              <td><span class="badge bg-<?php echo $statusDot[$o['order_status']] ?? 'secondary'; ?>"><?php echo e($o['order_status']); ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card border-0 shadow-sm mb-4">
      <div class="card-header bg-white fw-bold">Orders by Status</div>
      <div class="card-body">
        <?php if (!$statusCounts): ?><p class="text-muted small mb-0">No data yet.</p><?php endif; ?>
        <?php foreach (['Pending','Confirmed','Processing','Shipped','Delivered','Cancelled'] as $st):
            $cnt = $statusMap[$st] ?? 0; $pct = $stats['orders'] ? round($cnt / $stats['orders'] * 100) : 0; ?>
          <div class="d-flex justify-content-between small mb-1">
            <span><span class="badge bg-<?php echo $statusDot[$st]; ?>"><?php echo $st; ?></span></span>
            <span class="fw-semibold"><?php echo $cnt; ?></span>
          </div>
          <div class="progress mb-3" style="height:6px;">
            <div class="progress-bar bg-<?php echo $statusDot[$st]; ?>" style="width:<?php echo $pct; ?>%"></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="card border-0 shadow-sm">
      <div class="card-header bg-white fw-bold">Low Stock Alerts</div>
      <div class="card-body">
        <?php if (!$lowStock): ?><p class="text-muted small mb-0">All products sufficiently stocked. ✅</p><?php endif; ?>
        <?php foreach ($lowStock as $lp): ?>
          <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="small"><?php echo e($lp['name']); ?></span>
            <span class="badge bg-danger"><?php echo (int)$lp['stock']; ?> left</span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
