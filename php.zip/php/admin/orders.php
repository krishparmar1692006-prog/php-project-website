<?php
/**
 * ADMIN ORDERS - view all orders, details, update order status & payment status.
 */
$pageTitle = 'Orders';
require_once __DIR__ . '/includes/header.php';

/* Update status */
if (isset($_POST['update_status']) && isset($_POST['order_id'])) {
    $oid     = (int)$_POST['order_id'];
    $ostatus = $_POST['order_status'];
    $pstatus = $_POST['payment_status'];
    $validO  = ['Pending','Confirmed','Processing','Shipped','Delivered','Cancelled'];
    $validP  = ['Unpaid','Paid','Refunded'];
    $ostatus = in_array($ostatus, $validO, true) ? $ostatus : 'Pending';
    $pstatus = in_array($pstatus, $validP, true) ? $pstatus : 'Unpaid';
    $pdo->prepare('UPDATE orders SET order_status=?, payment_status=? WHERE id=?')
       ->execute([$ostatus, $pstatus, $oid]);
    setFlash('success', 'Order #' . $oid . ' status updated.');
    header('Location: orders.php?view=' . $oid); exit;
}

$orders = $pdo->query('SELECT o.*, u.name AS customer FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC')->fetchAll();

$detailId = isset($_GET['view']) ? (int)$_GET['view'] : 0;
$detail = null; $detailItems = [];
if ($detailId) {
    $d = $pdo->prepare('SELECT o.*, u.name AS customer FROM orders o JOIN users u ON u.id=o.user_id WHERE o.id=?');
    $d->execute([$detailId]);
    $detail = $d->fetch();
    if ($detail) {
        $di = $pdo->prepare('SELECT * FROM order_items WHERE order_id=?');
        $di->execute([$detailId]);
        $detailItems = $di->fetchAll();
    }
}
$dot = ['Pending'=>'secondary','Confirmed'=>'primary','Processing'=>'info','Shipped'=>'warning','Delivered'=>'success','Cancelled'=>'danger'];
$payDot = ['Unpaid'=>'danger','Paid'=>'success','Refunded'=>'secondary'];
?>
<div class="card border-0 shadow-sm">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr><th>Order ID</th><th>Customer</th><th>Date</th><th>Items</th><th>Total</th><th>Payment</th><th>Pay Status</th><th>Order Status</th><th></th></tr>
      </thead>
      <tbody>
      <?php if (!$orders): ?><tr><td colspan="9" class="text-center text-muted py-4">No orders yet.</td></tr><?php endif; ?>
      <?php foreach ($orders as $o):
          $items = (int)$pdo->query('SELECT COUNT(*) c FROM order_items WHERE order_id=' . (int)$o['id'])->fetch()['c']; ?>
        <tr>
          <td class="fw-semibold">#<?php echo e($o['order_number']); ?></td>
          <td><?php echo e($o['customer']); ?></td>
          <td><?php echo date('d M Y', strtotime($o['order_date'])); ?></td>
          <td><?php echo $items; ?></td>
          <td class="fw-bold"><?php echo money($o['total_amount']); ?></td>
          <td><?php echo e($o['payment_method']); ?></td>
          <td><span class="badge bg-<?php echo $payDot[$o['payment_status']] ?? 'danger'; ?>"><?php echo e($o['payment_status']); ?></span></td>
          <td><span class="badge bg-<?php echo $dot[$o['order_status']] ?? 'secondary'; ?>"><?php echo e($o['order_status']); ?></span></td>
          <td><a href="orders.php?view=<?php echo (int)$o['id']; ?>" class="btn btn-sm btn-outline-primary">View</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if ($detail): ?>
<div class="modal fade show d-block" tabindex="-1" style="background:rgba(0,0,0,.5);">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">Order #<?php echo e($detail['order_number']); ?></h5>
        <a href="orders.php" class="btn-close btn-close-white"></a>
      </div>
      <div class="modal-body">
        <div class="row g-3 small mb-3">
          <div class="col-md-4"><span class="text-muted d-block">Customer</span><strong><?php echo e($detail['customer']); ?> (<?php echo e($detail['email']); ?></strong>)</div>
          <div class="col-md-4"><span class="text-muted d-block">Ordered On</span><strong><?php echo niceDate($detail['order_date']); ?></strong></div>
          <div class="col-md-4"><span class="text-muted d-block">Mobile</span><strong><?php echo e($detail['mobile']); ?></strong></div>
          <div class="col-12"><span class="text-muted d-block">Shipping Address</span>
            <strong><?php echo e($detail['shipping_address']); ?>, <?php echo e($detail['city']); ?>, <?php echo e($detail['state']); ?> - <?php echo e($detail['pincode']); ?></strong>
          </div>
        </div>

        <table class="table table-sm table-bordered align-middle">
          <thead class="table-light"><tr><th>Product</th><th>Price</th><th>Qty</th><th class="text-end">Subtotal</th></tr></thead>
          <tbody>
          <?php foreach ($detailItems as $oi): ?>
            <tr>
              <td><?php echo e($oi['product_name']); ?></td>
              <td><?php echo money($oi['price']); ?></td>
              <td><?php echo (int)$oi['quantity']; ?></td>
              <td class="text-end"><?php echo money($oi['price'] * $oi['quantity']); ?></td>
            </tr>
          <?php endforeach; ?>
          <tr class="table-light"><td colspan="3" class="text-end fw-bold">Total Amount</td>
            <td class="text-end fw-bold text-primary"><?php echo money($detail['total_amount']); ?></td></tr>
          </tbody>
        </table>

        <form method="post" action="orders.php" class="row g-3 align-items-end bg-light p-3 rounded">
          <input type="hidden" name="update_status" value="1">
          <input type="hidden" name="order_id" value="<?php echo (int)$detail['id']; ?>">
          <div class="col-md-5">
            <label class="form-label">Order Status</label>
            <select name="order_status" class="form-select">
              <?php foreach (array_keys($dot) as $st): ?>
                <option <?php echo $detail['order_status'] === $st ? 'selected' : ''; ?>><?php echo $st; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">Payment Status</label>
            <select name="payment_status" class="form-select">
              <?php foreach (array_keys($payDot) as $ps): ?>
                <option <?php echo $detail['payment_status'] === $ps ? 'selected' : ''; ?>><?php echo $ps; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-3">
            <button class="btn btn-primary w-100">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
