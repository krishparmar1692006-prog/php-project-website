<?php
/** ADMIN USERS - list, search, edit, activate/deactivate. */
$pageTitle = 'Users';
require_once __DIR__ . '/includes/header.php';

// Actions: toggle status / delete
if (isset($_GET['action'], $_GET['id'])) {
    $uid = (int)$_GET['id'];
    if ($_GET['action'] === 'toggle') {
        $u = $pdo->prepare('SELECT status FROM users WHERE id=?')
             ->execute([$uid]) ? null : null;
        $u = $pdo->query('SELECT status FROM users WHERE id=' . $uid)->fetch();
        if ($u) {
            $new = $u['status'] ? 0 : 1;
            $pdo->prepare('UPDATE users SET status=? WHERE id=?')->execute([$new, $uid]);
            setFlash('success', $new ? 'User activated.' : 'User deactivated.');
        }
        header('Location: users.php'); exit;
    }
    if ($_GET['action'] === 'delete') {
        $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$uid]);
        setFlash('success', 'User deleted.');
        header('Location: users.php'); exit;
    }
}

// Edit modal target
$editUser = null;
if (isset($_GET['edit'])) {
    $eu = $pdo->prepare('SELECT * FROM users WHERE id=?');
    $eu->execute([(int)$_GET['edit']]);
    $editUser = $eu->fetch();
}

// Update logic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
    $eid = (int)$_POST['edit_id'];
    $name = trim($_POST['name']); $email = trim($_POST['email']); $mobile = trim($_POST['mobile']);
    $address = trim($_POST['address']); $city = trim($_POST['city']); $state = trim($_POST['state']); $pincode = trim($_POST['pincode']);
    $status = isset($_POST['status']) ? 1 : 0;
    $pdo->prepare('UPDATE users SET name=?, email=?, mobile=?, address=?, city=?, state=?, pincode=?, status=? WHERE id=?')
       ->execute([$name, $email, $mobile, $address, $city, $state, $pincode, $status, $eid]);
    setFlash('success', 'User details updated.');
    header('Location: users.php'); exit;
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE name LIKE ? OR email LIKE ? OR mobile LIKE ? ORDER BY id DESC');
    $stmt->execute(['%'.$search.'%','%'.$search.'%','%'.$search.'%']);
    $users = $stmt->fetchAll();
} else {
    $users = $pdo->query('SELECT * FROM users ORDER BY id DESC')->fetchAll();
}
?>
<form class="d-flex mb-4" method="get" action="users.php">
  <input type="search" name="search" class="form-control me-2" style="max-width:320px;" placeholder="Search by name, email or mobile..." value="<?php echo e($search); ?>">
  <button class="btn btn-primary"><i class="bi bi-search"></i></button>
</form>

<div class="card border-0 shadow-sm">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Mobile</th><th>City</th><th>Joined</th><th>Status</th><th>Actions</th></tr>
      </thead>
      <tbody>
      <?php if (!$users): ?><tr><td colspan="8" class="text-center text-muted py-4">No users found.</td></tr><?php endif; ?>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?php echo (int)$u['id']; ?></td>
          <td class="fw-semibold"><?php echo e($u['name']); ?></td>
          <td><?php echo e($u['email']); ?></td>
          <td><?php echo e($u['mobile']); ?></td>
          <td><?php echo e($u['city'] ?: '-'); ?></td>
          <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
          <td>
            <span class="badge <?php echo $u['status'] ? 'bg-success' : 'bg-secondary'; ?>"><?php echo $u['status'] ? 'Active' : 'Inactive'; ?></span>
          </td>
          <td>
            <a href="users.php?edit=<?php echo (int)$u['id']; ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
            <a href="users.php?action=toggle&id=<?php echo (int)$u['id']; ?>" class="btn btn-sm btn-outline-warning" title="Activate/Deactivate"><i class="bi bi-pause-circle"></i></a>
            <a href="users.php?action=delete&id=<?php echo (int)$u['id']; ?>" class="btn btn-sm btn-outline-danger" title="Delete" onclick="return confirm('Delete this user?')"><i class="bi bi-trash"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if ($editUser): ?>
<div class="modal fade show d-block" tabindex="-1" style="background:rgba(0,0,0,.5);">
  <div class="modal-dialog modal-lg">
    <form method="post" action="users.php" class="modal-content">
      <input type="hidden" name="edit_id" value="<?php echo (int)$editUser['id']; ?>">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">Edit User #<?php echo (int)$editUser['id']; ?></h5>
        <a href="users.php" class="btn-close btn-close-white"></a>
      </div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">Name</label><input type="text" name="name" class="form-control" value="<?php echo e($editUser['name']); ?>" required></div>
          <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?php echo e($editUser['email']); ?>" required></div>
          <div class="col-md-6"><label class="form-label">Mobile</label><input type="text" name="mobile" class="form-control" value="<?php echo e($editUser['mobile']); ?>" required></div>
          <div class="col-md-6"><label class="form-label">Pincode</label><input type="text" name="pincode" class="form-control" value="<?php echo e($editUser['pincode']); ?>"></div>
          <div class="col-12"><label class="form-label">Address</label><input type="text" name="address" class="form-control" value="<?php echo e($editUser['address']); ?>"></div>
          <div class="col-md-6"><label class="form-label">City</label><input type="text" name="city" class="form-control" value="<?php echo e($editUser['city']); ?>"></div>
          <div class="col-md-6"><label class="form-label">State</label><input type="text" name="state" class="form-control" value="<?php echo e($editUser['state']); ?>"></div>
          <div class="col-12">
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" name="status" id="uStatus" <?php echo $editUser['status'] ? 'checked' : ''; ?>>
              <label class="form-check-label" for="uStatus">Active account</label>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <a href="users.php" class="btn btn-secondary">Cancel</a>
        <button class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
