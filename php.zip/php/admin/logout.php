<?php
/** ADMIN LOGOUT */
require_once __DIR__ . '/../includes/config.php';
unset($_SESSION['admin_id'], $_SESSION['admin_name']);
header('Location: index.php');
exit;
