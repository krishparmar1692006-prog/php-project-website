<?php
/**
 * Admin shared layout header (sidebar + topbar).
 * Includes auth guard - so every admin page gets protected automatically.
 */
require_once __DIR__ . '/auth.php';
$SITE_ROOT = '..';
$page = basename($_SERVER['PHP_SELF']);
$adminName = $_SESSION['admin_name'] ?? 'Admin';
$ADMIN_NAV = [
    ['dashboard.php', 'bi-grid', 'Dashboard'],
    ['users.php', 'bi-people', 'Users'],
    ['categories.php', 'bi-tags', 'Categories'],
    ['products.php', 'bi-box-seam', 'Products'],
    ['orders.php', 'bi-cart-check', 'Orders'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? e($pageTitle) . ' | ' : ''; ?>TechCart Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrap">
  <aside class="admin-sidebar d-flex flex-column">
    <div class="p-3 text-center border-bottom" style="border-color:rgba(255,255,255,.12)!important;">
      <a href="dashboard.php" class="text-decoration-none text-white fw-bold fs-5"><i class="bi bi-shield-lock me-1"></i>TechCart<span class="text-warning"> Admin</span></a>
    </div>
    <nav class="nav flex-column flex-grow-1 py-2">
      <?php foreach ($ADMIN_NAV as $item): ?>
        <a class="nav-link <?php echo $page === $item[0] ? 'active' : ''; ?>" href="<?php echo $item[0]; ?>">
          <i class="bi <?php echo $item[1]; ?> me-2"></i><?php echo $item[2]; ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="p-3 border-top" style="border-color:rgba(255,255,255,.12)!important;">
      <div class="small text-muted mb-2"><i class="bi bi-person-circle me-1"></i><?php echo e($adminName); ?></div>
      <a href="logout.php" class="btn btn-sm btn-outline-light w-100"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
    </div>
  </aside>
  <main class="admin-main">
    <h4 class="mb-4 fw-bold"><?php echo $pageTitle ?? 'Dashboard'; ?></h4>
    <?php echo renderFlash(); ?>
