<?php
/**
 * Helper to handle admin image uploads.
 * Saves a file into /uploads and returns the relative DB path.
 * Returns empty string on failure (with $error message updated).
 */
$error = '';
function handleImageUpload($fieldName, &$error)
{
    if (empty($_FILES[$fieldName]['name'])) {
        return ''; // no file uploaded
    }
    $file = $_FILES[$fieldName];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'File upload error (code ' . $file['error'] . ').';
        return '';
    }
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/svg+xml' => 'svg', 'image/gif' => 'gif'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!isset($allowed[$mime])) {
        $error = 'Only JPG, PNG, WebP, SVG or GIF images are allowed.';
        return '';
    }
    if ($file['size'] > 2 * 1024 * 1024) {
        $error = 'Image must be under 2 MB.';
        return '';
    }
    $ext   = $allowed[$mime];
    $name  = 'img_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dir   = __DIR__ . '/../uploads';
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
        $error = 'Could not save the uploaded file.';
        return '';
    }
    return 'uploads/' . $name;
}
