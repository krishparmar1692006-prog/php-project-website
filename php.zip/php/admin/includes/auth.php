<?php
/** Admin section guard - redirects to login if not authenticated. */
require_once __DIR__ . '/../../includes/config.php';
if (!isAdminLoggedIn()) {
    header('Location: index.php');
    exit;
}
