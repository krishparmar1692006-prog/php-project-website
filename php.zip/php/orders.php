<?php
/**
 * ORDER HISTORY PAGE - shows all orders of the logged-in customer.
 */
$pageTitle = 'Order History';
require_once __DIR__ . '/includes/header.php';

if (!isLoggedIn()) {
    setFlash('warning', 'Please log in to view your orders.');
    redirect('login.php');
}

$stmt = $pdo->prepare('SELECT o.*, (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) AS item_count
                       FROM orders o WHERE o.user_id = ? ORDER BY o.id DESC');
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();

// If viewing details
$detailId = isset($_GET['view']) ? (int)$_GET['view'] : 0;
$orderDetail = null;
$detailItems = [];
if ($detailId) {
    $od = $pdo->prepare('SELECT * FROM orders WHERE id=? AND user_id=?');
    $od->execute([$detailId, $_SESSION['user_id']]);
    $orderDetail = $od->fetch();
    if ($orderDetail) {
        $di = $pdo->prepare('SELECT * FROM order_items WHERE order_id=?');
        $di->execute([$detailId]);
        $detailItems = $di->fetchAll();
    }
}
?>
<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item active">Order History</li>
  </ol></nav>
  <h3 class="section-title mb-4">My Orders</h3>

  <?php if ($detailId && $orderDetail): ?>
    <div class="card border-0 shadow-sm mb-4">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 class="fw-bold mb-0">Order #<?php echo e($orderDetail['order_number']); ?></h5>
          <a href="orders.php" class="btn btn-sm btn-brand-outline"><i class="bi bi-arrow-left me-1"></i>Back to Orders</a>
        </div>
        <div class="row g-3 mb-3 small">
          <div class="col-md-3"><span class="text-muted d-block">Order Date</span><strong><?php echo niceDate($orderDetail['order_date']); ?></strong></div>
          <div class="col-md-3"><span class="text-muted d-block">Payment</span><strong><?php echo e($orderDetail['payment_method']); ?></strong></div>
          <div class="col-md-3"><span class="text-muted d-block">Amount</span><strong class="text-primary"><?php echo money($orderDetail['total_amount']); ?></strong></div>
          <div class="col-md-3"><span class="text-muted d-block">Status</span><strong><?php echo e($orderDetail['order_status']); ?></strong></div>
        </div>
        <table class="table table-sm table-bordered align-middle">
          <thead class="table-light"><tr><th>Product</th><th>Price</th><th>Qty</th><th class="text-end">Subtotal</th></tr></thead>
          <tbody>
          <?php foreach ($detailItems as $oi): ?>
            <tr>
              <td><?php echo e($oi['product_name']); ?></td>
              <td><?php echo money($oi['price']); ?></td>
              <td><?php echo (int)$oi['quantity']; ?></td>
              <td class="text-end"><?php echo money($oi['price'] * $oi['quantity']); ?></td>
            </tr>
          <?php endforeach; ?>
          <tr class="table-light"><td colspan="3" class="text-end fw-bold">Total</td><td class="text-end fw-bold text-primary"><?php echo money($orderDetail['total_amount']); ?></td></tr>
          </tbody>
        </table>
        <p class="small text-muted mb-0">Ship to: <?php echo e($orderDetail['shipping_address']); ?>, <?php echo e($orderDetail['city']); ?>, <?php echo e($orderDetail['state']); ?> - <?php echo e($orderDetail['pincode']); ?></p>
      </div>
    </div>
  <?php endif; ?>

  <?php if (!$orders): ?>
    <div class="text-center py-5">
      <i class="bi bi-inbox display-1 text-muted"></i>
      <h5 class="mt-3">No orders yet</h5>
      <p class="text-muted">When you place an order, it will appear here.</p>
      <a href="products.php" class="btn btn-brand">Start Shopping</a>
    </div>
  <?php else: ?>
  <div class="card border-0 shadow-sm">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr><th>Order ID</th><th>Date</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($orders as $o): ?>
          <tr>
            <td class="fw-semibold">#<?php echo e($o['order_number']); ?></td>
            <td><?php echo date('d M Y', strtotime($o['order_date'])); ?></td>
            <td><?php echo (int)$o['item_count']; ?> product(s)</td>
            <td class="fw-bold"><?php echo money($o['total_amount']); ?></td>
            <td><?php echo e($o['payment_method']); ?></td>
            <td>
              <?php
                $map = ['Pending'=>'secondary','Confirmed'=>'primary','Processing'=>'info','Shipped'=>'warning','Delivered'=>'success','Cancelled'=>'danger'];
                $badge = $map[$o['order_status']] ?? 'secondary';
              ?>
              <span class="badge bg-<?php echo $badge; ?>"><?php echo e($o['order_status']); ?></span>
            </td>
            <td><a href="orders.php?view=<?php echo (int)$o['id']; ?>" class="btn btn-sm btn-brand-outline">View Details</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
